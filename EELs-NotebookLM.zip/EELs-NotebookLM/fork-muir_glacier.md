# EELS Hard Fork: muir_glacier

Ethereum Execution Layer Specs (EELS) — pure source export for NotebookLM.
Each section is one original file. Path headers preserve the upstream layout.

Source tree root: ethereum/
File count in this document: 41


================================================================================
FILE: ethereum/forks/muir_glacier/__init__.py
================================================================================

```python
"""
The Muir Glacier fork delays the difficulty bomb. There are no other changes
in this fork.

### Changes

- [EIP-2384: Muir Glacier Difficulty Bomb Delay][EIP-2384]

### Upgrade Schedule

| Network | Block        | Expected Date    | Fork Hash    |
| ------- | ------------ | ---------------- | ------------ |
| Ropsten |  7,117,117   |                  |              |
| Mainnet |  9,200,000   | January 2, 2020  | `0xe029e991` |

### Releases

- [Geth 1.9.9]
- [Parity 2.6.8-beta][p]
- [Besu 1.3.7]
- [Nethermind 1.2.6][n]
- [EthereumJS 4.1.2][js]
- [Aleth 1.8.0][a]
- [Trinity 0.1.0-alpha.34][t]

[EIP-2384]: https://eips.ethereum.org/EIPS/eip-2384
[Geth 1.9.9]: https://github.com/ethereum/go-ethereum/releases/tag/v1.9.9
[p]: https://github.com/paritytech/parity-ethereum/releases/tag/v2.6.8
[Besu 1.3.7]: https://github.com/besu-eth/besu/releases/tag/1.3.7
[n]: https://github.com/NethermindEth/nethermind/releases/tag/1.2.6
[js]: https://github.com/ethereumjs/ethereumjs-vm/releases/tag/v4.1.2
[a]: https://github.com/ethereum/aleth/releases/tag/v1.8.0
[t]: https://github.com/ethereum/trinity/releases/tag/v0.1.0-alpha.34
"""

from ethereum.fork_criteria import ByBlockNumber, ForkCriteria

FORK_CRITERIA: ForkCriteria = ByBlockNumber(9200000)

```


================================================================================
FILE: ethereum/forks/muir_glacier/blocks.py
================================================================================

```python
"""
A `Block` is a single link in the chain that is Ethereum. Each `Block` contains
a `Header` and zero or more transactions. Each `Header` contains associated
metadata like the block number, parent block hash, and how much gas was
consumed by its transactions.

Together, these blocks form a cryptographically secure journal recording the
history of all state transitions that have happened since the genesis of the
chain.
"""

from dataclasses import dataclass
from typing import Tuple, final

from ethereum_types.bytes import Bytes, Bytes8, Bytes32
from ethereum_types.frozen import slotted_freezable
from ethereum_types.numeric import U256, Uint

from ethereum.crypto.hash import Hash32
from ethereum.state import Address, Root

from .fork_types import Bloom
from .transactions import Transaction


@final
@slotted_freezable
@dataclass
class Header:
    """
    Header portion of a block on the chain, containing metadata and
    cryptographic commitments to the block's contents.
    """

    parent_hash: Hash32
    """
    Hash ([`keccak256`]) of the parent block's header, encoded with [RLP].

    [`keccak256`]: ref:ethereum.crypto.hash.keccak256
    [RLP]: https://ethereum.github.io/ethereum-rlp/src/ethereum_rlp/rlp.py.html
    """

    ommers_hash: Hash32
    """
    Hash ([`keccak256`]) of the ommers (uncle blocks) in this block, encoded
    with [RLP].

    [`keccak256`]: ref:ethereum.crypto.hash.keccak256
    [RLP]: https://ethereum.github.io/ethereum-rlp/src/ethereum_rlp/rlp.py.html
    """

    coinbase: Address
    """
    Address of the miner who mined this block.

    The coinbase address receives the block reward and all transaction fees
    (gas price * gas used) from included transactions in the block.
    """

    state_root: Root
    """
    Root hash ([`keccak256`]) of the state trie after executing all
    transactions in this block. It represents the state of the Ethereum Virtual
    Machine (EVM) after all transactions in this block have been processed. It
    is computed using [`compute_state_root_and_trie_changes()`][changes],
    which computes the root of the Merkle-Patricia [Trie] representing the
    Ethereum world state after applying the block's state changes.

    [`keccak256`]: ref:ethereum.crypto.hash.keccak256
    [changes]: ref:ethereum.state.State.compute_state_root_and_trie_changes
    [Trie]: ref:ethereum.merkle_patricia_trie.Trie
    """  # noqa: E501

    transactions_root: Root
    """
    Root hash ([`keccak256`]) of the transactions trie, which contains all
    transactions included in this block in their original order. It is computed
    using the [`root()`] function over the Merkle-Patricia [trie] of
    transactions as the parameter.

    [`keccak256`]: ref:ethereum.crypto.hash.keccak256
    [`root()`]: ref:ethereum.merkle_patricia_trie.root
    [Trie]: ref:ethereum.merkle_patricia_trie.Trie
    """

    receipt_root: Root
    """
    Root hash ([`keccak256`]) of the receipts trie, which contains all receipts
    for transactions in this block. It is computed using the [`root()`]
    function over the Merkle-Patricia [trie] constructed from the receipts.

    [`keccak256`]: ref:ethereum.crypto.hash.keccak256
    [`root()`]: ref:ethereum.merkle_patricia_trie.root
    [Trie]: ref:ethereum.merkle_patricia_trie.Trie
    """

    bloom: Bloom
    """
    Bloom filter for logs generated by transactions in this block.
    Constructed from all logs in the block using the [logs bloom] mechanism.

    [logs bloom]: ref:ethereum.forks.muir_glacier.bloom.logs_bloom
    """

    difficulty: Uint
    """
    Difficulty of the block, used in Proof-of-Work to determine the effort
    required to mine the block. This value adjusts over time to maintain a
    relatively constant block time and is computed using the
    [`calculate_block_difficulty()`] function.

    [`calculate_block_difficulty()`]:
    ref:ethereum.forks.muir_glacier.fork.calculate_block_difficulty
    """

    number: Uint
    """
    Block number (height) in the chain.
    """

    gas_limit: Uint
    """
    Maximum gas allowed in this block. Pre [EIP-1559], this is the maximum
    gas that could be consumed by all transactions in the block.

    [EIP-1559]: https://eips.ethereum.org/EIPS/eip-1559
    """

    gas_used: Uint
    """
    Total gas used by all transactions in this block.
    """

    timestamp: U256
    """
    Timestamp of when the block was mined, in seconds since the unix epoch.
    """

    extra_data: Bytes
    """
    Arbitrary data included by the miner.
    """

    mix_digest: Bytes32
    """
    Mix hash used in the mining process, which is a cryptographic commitment
    to the block's contents. It [validates][u] that PoW was done on the correct
    block.

    [u]: ref:ethereum.forks.muir_glacier.fork.validate_proof_of_work
    """

    nonce: Bytes8
    """
    Nonce used in the mining process, which is a value that miners
    increment to find a valid block hash. This is also used to [validate][v]
    the proof-of-work for this block.

    [v]: ref:ethereum.forks.muir_glacier.fork.validate_proof_of_work
    """


@final
@slotted_freezable
@dataclass
class Block:
    """
    A complete block on Ethereum, which is composed of a block [`header`],
    a list of transactions, and a list of ommers (also known as uncle blocks).

    The block [`header`] includes PoW-specific fields such as `difficulty`,
    `nonce`, and `ommersHash`, which relate to the mining process. The
    `coinbase` field denotes the address receiving mining and transaction
    fees.

    The header also contains commitments to the current state (`stateRoot`),
    the transactions (`transactionsRoot`), and the transaction receipts
    (`receiptsRoot`). It also includes a bloom filter which summarizes log
    data from the transactions.

    Ommers are used to provide rewards for near-valid mined blocks that didn't
    become part of the canonical chain.

    [`header`]: ref:ethereum.forks.muir_glacier.blocks.Header
    """

    header: Header
    """
    The block header containing metadata and cryptographic commitments. Refer
    to [headers] for more details on the fields included in the header.

    [headers]: ref:ethereum.forks.muir_glacier.blocks.Header
    """

    transactions: Tuple[Transaction, ...]
    """
    A tuple of transactions included in this block.
    """

    ommers: Tuple[Header, ...]
    """
    A tuple of ommers (uncle blocks) included in this block. Ommers are
    blocks that were mined at the same time as this block but were not
    included in the main chain.
    """


@final
@slotted_freezable
@dataclass
class Log:
    """
    Data record produced during the execution of a transaction. Logs are used
    by smart contracts to emit events (using the EVM log opcodes ([`LOG0`],
    [`LOG1`], [`LOG2`], [`LOG3`] and [`LOG4`]), which can be efficiently
    searched using the bloom filter in the block header.

    [`LOG0`]: ref:ethereum.forks.muir_glacier.vm.instructions.log.log0
    [`LOG1`]: ref:ethereum.forks.muir_glacier.vm.instructions.log.log1
    [`LOG2`]: ref:ethereum.forks.muir_glacier.vm.instructions.log.log2
    [`LOG3`]: ref:ethereum.forks.muir_glacier.vm.instructions.log.log3
    [`LOG4`]: ref:ethereum.forks.muir_glacier.vm.instructions.log.log4
    """

    address: Address
    """
    The address of the contract that emitted the log.
    """

    topics: Tuple[Hash32, ...]
    """
    A tuple of up to four topics associated with the log, used for filtering.
    """

    data: Bytes
    """
    The data payload of the log, which can contain any arbitrary data.
    """


@final
@slotted_freezable
@dataclass
class Receipt:
    """
    Result of a transaction execution. Receipts are included in the receipts
    trie.
    """

    succeeded: bool
    """
    Whether the transaction execution was successful.
    """

    cumulative_gas_used: Uint
    """
    Total gas used in the block up to and including this transaction.
    """

    bloom: Bloom
    """
    Bloom filter for logs generated by this transaction. This is a 2048-byte
    bit array that allows for efficient filtering of logs.
    """

    logs: Tuple[Log, ...]
    """
    A tuple of logs generated by this transaction. Each log contains the
    address of the contract that emitted it, a tuple of topics, and the data
    payload.
    """

```


================================================================================
FILE: ethereum/forks/muir_glacier/bloom.py
================================================================================

```python
"""
Ethereum Logs Bloom.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

This module defines functions for calculating bloom filters of logs. For the
general theory of bloom filters see e.g. `Wikipedia
<https://en.wikipedia.org/wiki/Bloom_filter>`_. Bloom filters are used to allow
for efficient searching of logs by address and/or topic, by rapidly
eliminating blocks and receipts from their search.
"""

from typing import Tuple

from ethereum_types.bytes import Bytes
from ethereum_types.numeric import Uint

from ethereum.crypto.hash import keccak256

from .blocks import Log
from .fork_types import Bloom


def add_to_bloom(bloom: bytearray, bloom_entry: Bytes) -> None:
    """
    Add a bloom entry to the bloom filter (`bloom`).

    The number of hash functions used is 3. They are calculated by taking the
    least significant 11 bits from the first 3 16-bit words of the
    `keccak_256()` hash of `bloom_entry`.

    Parameters
    ----------
    bloom :
        The bloom filter.
    bloom_entry :
        An entry which is to be added to bloom filter.

    """
    hashed = keccak256(bloom_entry)

    for idx in (0, 2, 4):
        # Obtain the least significant 11 bits from the pair of bytes
        # (16 bits), and set this bit in bloom bytearray.
        # The obtained bit is 0-indexed in the bloom filter from the least
        # significant bit to the most significant bit.
        bit_to_set = Uint.from_be_bytes(hashed[idx : idx + 2]) & Uint(0x07FF)
        # Below is the index of the bit in the bytearray (where 0-indexed
        # byte is the most significant byte)
        bit_index = 0x07FF - int(bit_to_set)

        byte_index = bit_index // 8
        bit_value = 1 << (7 - (bit_index % 8))
        bloom[byte_index] = bloom[byte_index] | bit_value


def logs_bloom(logs: Tuple[Log, ...]) -> Bloom:
    """
    Obtain the logs bloom from a list of log entries.

    The address and each topic of a log are added to the bloom filter.

    Parameters
    ----------
    logs :
        List of logs for which the logs bloom is to be obtained.

    Returns
    -------
    logs_bloom : `Bloom`
        The logs bloom obtained which is 256 bytes with some bits set as per
        the caller address and the log topics.

    """
    bloom: bytearray = bytearray(b"\x00" * 256)

    for log in logs:
        add_to_bloom(bloom, log.address)
        for topic in log.topics:
            add_to_bloom(bloom, topic)

    return Bloom(bloom)

```


================================================================================
FILE: ethereum/forks/muir_glacier/exceptions.py
================================================================================

```python
"""
Exceptions specific to this fork.
"""

from ethereum_types.numeric import U64

from ethereum.exceptions import InvalidTransaction


class WrongChainIdError(InvalidTransaction):
    """
    Chain identifier from a transaction does not match the executing chain. See
    [EIP-155].

    [EIP-155]: https://eips.ethereum.org/EIPS/eip-155
    """

    def __init__(self, expected: U64, actual: U64):
        super().__init__(f"expected chain_id `{expected}` but got `{actual}`")
        self.expected = expected
        self.actual = actual

```


================================================================================
FILE: ethereum/forks/muir_glacier/fork_types.py
================================================================================

```python
"""
Ethereum Types.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Types reused throughout the specification, which are specific to Ethereum.
"""

from ethereum_rlp import rlp
from ethereum_types.bytes import Bytes, Bytes256

from ethereum.state import Account

Bloom = Bytes256


def encode_account(raw_account_data: Account, storage_root: Bytes) -> Bytes:
    """
    Encode `Account` dataclass.

    Storage is not stored in the `Account` dataclass, so `Accounts` cannot be
    encoded without providing a storage root.
    """
    return rlp.encode(
        (
            raw_account_data.nonce,
            raw_account_data.balance,
            storage_root,
            raw_account_data.code_hash,
        )
    )

```


================================================================================
FILE: ethereum/forks/muir_glacier/fork.py
================================================================================

```python
"""
Ethereum Specification.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Entry point for the Ethereum specification.
"""

from dataclasses import dataclass
from typing import List, Optional, Set, Tuple, final

from ethereum_rlp import rlp
from ethereum_types.numeric import U64, U256, Uint

from ethereum.crypto.hash import Hash32, keccak256
from ethereum.ethash import dataset_size, generate_cache, hashimoto_light
from ethereum.exceptions import (
    EthereumException,
    GasUsedExceedsLimitError,
    InsufficientBalanceError,
    InvalidBlock,
    InvalidSenderError,
    NonceMismatchError,
)
from ethereum.merkle_patricia_trie import root, trie_set
from ethereum.state import (
    EMPTY_CODE_HASH,
    Address,
    State,
    apply_changes_to_state,
)

from . import vm
from .blocks import Block, Header, Log, Receipt
from .bloom import logs_bloom
from .exceptions import WrongChainIdError
from .state_tracker import (
    BlockState,
    TransactionState,
    account_exists_and_is_empty,
    create_ether,
    destroy_account,
    destroy_touched_empty_accounts,
    extract_block_diff,
    get_account,
    incorporate_tx_into_block,
    increment_nonce,
    set_account_balance,
)
from .transactions import (
    Transaction,
    chain_id,
    get_transaction_hash,
    recover_sender,
    validate_transaction,
)
from .utils.message import prepare_message
from .vm.gas import GasCosts
from .vm.interpreter import process_message_call

BLOCK_REWARD = U256(2 * 10**18)
MINIMUM_DIFFICULTY = Uint(131072)
MAX_OMMER_DEPTH = Uint(6)
BOMB_DELAY_BLOCKS = 9000000
EMPTY_OMMER_HASH = keccak256(rlp.encode([]))


@final
@dataclass
class BlockChain:
    """
    History and current state of the block chain.
    """

    blocks: List[Block]
    state: State
    chain_id: U64


def apply_fork(old: BlockChain) -> BlockChain:
    """
    Transforms the state from the previous hard fork (`old`) into the block
    chain object for this hard fork and returns it.

    When forks need to implement an irregular state transition, this function
    is used to handle the irregularity. See the :ref:`DAO Fork <dao-fork>` for
    an example.

    Parameters
    ----------
    old :
        Previous block chain object.

    Returns
    -------
    new : `BlockChain`
        Upgraded block chain object for this hard fork.

    """
    return old


def get_last_256_block_hashes(chain: BlockChain) -> List[Hash32]:
    """
    Obtain the list of hashes of the previous 256 blocks in order of
    increasing block number.

    This function will return less hashes for the first 256 blocks.

    The ``BLOCKHASH`` opcode needs to access the latest hashes on the chain,
    therefore this function retrieves them.

    Parameters
    ----------
    chain :
        History and current state.

    Returns
    -------
    recent_block_hashes : `List[Hash32]`
        Hashes of the recent 256 blocks in order of increasing block number.

    """
    recent_blocks = chain.blocks[-255:]
    # TODO: This function has not been tested rigorously
    if len(recent_blocks) == 0:
        return []

    recent_block_hashes = []

    for block in recent_blocks:
        prev_block_hash = block.header.parent_hash
        recent_block_hashes.append(prev_block_hash)

    # We are computing the hash only for the most recent block and not for
    # the rest of the blocks as they have successors which have the hash of
    # the current block as parent hash.
    most_recent_block_hash = keccak256(rlp.encode(recent_blocks[-1].header))
    recent_block_hashes.append(most_recent_block_hash)

    return recent_block_hashes


def state_transition(chain: BlockChain, block: Block) -> None:
    """
    Attempts to apply a block to an existing block chain.

    All parts of the block's contents need to be verified before being added
    to the chain. Blocks are verified by ensuring that the contents of the
    block make logical sense with the contents of the parent block. The
    information in the block's header must also match the corresponding
    information in the block.

    To implement Ethereum, in theory clients are only required to store the
    most recent 255 blocks of the chain since as far as execution is
    concerned, only those blocks are accessed. Practically, however, clients
    should store more blocks to handle reorgs.

    Parameters
    ----------
    chain :
        History and current state.
    block :
        Block to apply to `chain`.

    """
    validate_header(chain, block.header)
    validate_ommers(block.ommers, block.header, chain)

    block_state = BlockState(pre_state=chain.state)

    block_env = vm.BlockEnvironment(
        chain_id=chain.chain_id,
        state=block_state,
        block_gas_limit=block.header.gas_limit,
        block_hashes=get_last_256_block_hashes(chain),
        coinbase=block.header.coinbase,
        number=block.header.number,
        time=block.header.timestamp,
        difficulty=block.header.difficulty,
    )

    block_output = apply_body(
        block_env=block_env,
        transactions=block.transactions,
        ommers=block.ommers,
    )
    block_diff = extract_block_diff(block_state)
    block_state_root, _ = chain.state.compute_state_root_and_trie_changes(
        block_diff.account_changes,
        block_diff.storage_changes,
        block_diff.storage_clears,
    )
    transactions_root = root(block_output.transactions_trie)
    receipt_root = root(block_output.receipts_trie)
    block_logs_bloom = logs_bloom(block_output.block_logs)

    if block_output.block_gas_used != block.header.gas_used:
        raise InvalidBlock(
            f"{block_output.block_gas_used} != {block.header.gas_used}"
        )
    if transactions_root != block.header.transactions_root:
        raise InvalidBlock
    if block_state_root != block.header.state_root:
        raise InvalidBlock
    if receipt_root != block.header.receipt_root:
        raise InvalidBlock
    if block_logs_bloom != block.header.bloom:
        raise InvalidBlock

    apply_changes_to_state(chain.state, block_diff)
    chain.blocks.append(block)
    if len(chain.blocks) > 255:
        # Real clients have to store more blocks to deal with reorgs, but the
        # protocol only requires the last 255
        chain.blocks = chain.blocks[-255:]


def validate_header(chain: BlockChain, header: Header) -> None:
    """
    Verifies a block header.

    In order to consider a block's header valid, the logic for the
    quantities in the header should match the logic for the block itself.
    For example the header timestamp should be greater than the block's parent
    timestamp because the block was created *after* the parent block.
    Additionally, the block's number should be directly following the parent
    block's number since it is the next block in the sequence.

    Parameters
    ----------
    chain :
        History and current state.
    header :
        Header to check for correctness.

    """
    if header.number < Uint(1):
        raise InvalidBlock
    parent_header_number = header.number - Uint(1)
    first_block_number = chain.blocks[0].header.number
    last_block_number = chain.blocks[-1].header.number

    if (
        parent_header_number < first_block_number
        or parent_header_number > last_block_number
    ):
        raise InvalidBlock

    parent_header = chain.blocks[
        parent_header_number - first_block_number
    ].header

    if header.gas_used > header.gas_limit:
        raise InvalidBlock

    parent_has_ommers = parent_header.ommers_hash != EMPTY_OMMER_HASH
    if header.timestamp <= parent_header.timestamp:
        raise InvalidBlock
    if header.number != parent_header.number + Uint(1):
        raise InvalidBlock
    if not check_gas_limit(header.gas_limit, parent_header.gas_limit):
        raise InvalidBlock
    if len(header.extra_data) > 32:
        raise InvalidBlock

    block_difficulty = calculate_block_difficulty(
        header.number,
        header.timestamp,
        parent_header.timestamp,
        parent_header.difficulty,
        parent_has_ommers,
    )
    if header.difficulty != block_difficulty:
        raise InvalidBlock

    block_parent_hash = keccak256(rlp.encode(parent_header))
    if header.parent_hash != block_parent_hash:
        raise InvalidBlock

    validate_proof_of_work(header)


def generate_header_hash_for_pow(header: Header) -> Hash32:
    """
    Generate rlp hash of the header which is to be used for Proof-of-Work
    verification.

    In other words, the PoW artefacts `mix_digest` and `nonce` are ignored
    while calculating this hash.

    A particular PoW is valid for a single hash, that hash is computed by
    this function. The `nonce` and `mix_digest` are omitted from this hash
    because they are being changed by miners in their search for a sufficient
    proof-of-work.

    Parameters
    ----------
    header :
        The header object for which the hash is to be generated.

    Returns
    -------
    hash : `Hash32`
        The PoW valid rlp hash of the passed in header.

    """
    header_data_without_pow_artefacts = (
        header.parent_hash,
        header.ommers_hash,
        header.coinbase,
        header.state_root,
        header.transactions_root,
        header.receipt_root,
        header.bloom,
        header.difficulty,
        header.number,
        header.gas_limit,
        header.gas_used,
        header.timestamp,
        header.extra_data,
    )

    return keccak256(rlp.encode(header_data_without_pow_artefacts))


def validate_proof_of_work(header: Header) -> None:
    """
    Validates the Proof of Work constraints.

    In order to verify that a miner's proof-of-work is valid for a block, a
    ``mix-digest`` and ``result`` are calculated using the ``hashimoto_light``
    hash function. The mix digest is a hash of the header and the nonce that
    is passed through and it confirms whether or not proof-of-work was done
    on the correct block. The result is the actual hash value of the block.

    Parameters
    ----------
    header :
        Header of interest.

    """
    header_hash = generate_header_hash_for_pow(header)
    # TODO: Memoize this somewhere and read from that data instead of
    # calculating cache for every block validation.
    cache = generate_cache(header.number)
    mix_digest, result = hashimoto_light(
        header_hash, header.nonce, cache, dataset_size(header.number)
    )
    if mix_digest != header.mix_digest:
        raise InvalidBlock

    limit = Uint(U256.MAX_VALUE) + Uint(1)
    if Uint.from_be_bytes(result) > (limit // header.difficulty):
        raise InvalidBlock


def check_transaction(
    block_env: vm.BlockEnvironment,
    block_output: vm.BlockOutput,
    tx: Transaction,
    tx_state: TransactionState,
) -> Address:
    """
    Check if the transaction is includable in the block.

    Parameters
    ----------
    block_env :
        The block scoped environment.
    block_output :
        The block output for the current block.
    tx :
        The transaction.
    tx_state :
        The transaction state tracker.

    Returns
    -------
    sender_address :
        The sender of the transaction.

    Raises
    ------
    GasUsedExceedsLimitError :
        If the gas used by the transaction exceeds the block's gas limit.
    NonceMismatchError :
        If the nonce of the transaction is not equal to the sender's nonce.
    InsufficientBalanceError :
        If the sender's balance is not enough to pay for the transaction.
    InvalidSenderError :
        If the transaction is from an address that does not exist anymore.

    """
    gas_available = block_env.block_gas_limit - block_output.block_gas_used
    if tx.gas > gas_available:
        raise GasUsedExceedsLimitError("gas used exceeds limit")
    tx_chain_id = chain_id(tx)
    if tx_chain_id is not None and tx_chain_id != block_env.chain_id:
        raise WrongChainIdError(
            expected=block_env.chain_id,
            actual=tx_chain_id,
        )

    sender_address = recover_sender(tx)
    sender_account = get_account(tx_state, sender_address)

    max_gas_fee = tx.gas * tx.gas_price

    if sender_account.nonce > Uint(tx.nonce):
        raise NonceMismatchError("nonce too low")
    elif sender_account.nonce < Uint(tx.nonce):
        raise NonceMismatchError("nonce too high")
    if Uint(sender_account.balance) < max_gas_fee + Uint(tx.value):
        raise InsufficientBalanceError("insufficient sender balance")
    if sender_account.code_hash != EMPTY_CODE_HASH:
        raise InvalidSenderError("not EOA")

    return sender_address


def make_receipt(
    error: Optional[EthereumException],
    cumulative_gas_used: Uint,
    logs: Tuple[Log, ...],
) -> Receipt:
    """
    Make the receipt for a transaction that was executed.

    Parameters
    ----------
    tx :
        The executed transaction.
    error :
        Error in the top level frame of the transaction, if any.
    cumulative_gas_used :
        The total gas used so far in the block after the transaction was
        executed.
    logs :
        The logs produced by the transaction.

    Returns
    -------
    receipt :
        The receipt for the transaction.

    """
    receipt = Receipt(
        succeeded=error is None,
        cumulative_gas_used=cumulative_gas_used,
        bloom=logs_bloom(logs),
        logs=logs,
    )

    return receipt


def apply_body(
    block_env: vm.BlockEnvironment,
    transactions: Tuple[Transaction, ...],
    ommers: Tuple[Header, ...],
) -> vm.BlockOutput:
    """
    Executes a block.

    Many of the contents of a block are stored in data structures called
    tries. There is a transactions trie which is similar to a ledger of the
    transactions stored in the current block. There is also a receipts trie
    which stores the results of executing a transaction, like the post state
    and gas used. This function creates and executes the block that is to be
    added to the chain.

    Parameters
    ----------
    block_env :
        The block scoped environment.
    transactions :
        Transactions included in the block.
    ommers :
        Headers of ancestor blocks which are not direct parents (formerly
        uncles.)

    Returns
    -------
    block_output :
        The block output for the current block.

    """
    block_output = vm.BlockOutput()

    for i, tx in enumerate(transactions):
        process_transaction(block_env, block_output, tx, Uint(i))

    pay_rewards(block_env, ommers)

    return block_output


def validate_ommers(
    ommers: Tuple[Header, ...], block_header: Header, chain: BlockChain
) -> None:
    """
    Validates the ommers mentioned in the block.

    An ommer block is a block that wasn't canonically added to the
    blockchain because it wasn't validated as fast as the canonical block
    but was mined at the same time.

    To be considered valid, the ommers must adhere to the rules defined in
    the Ethereum protocol. The maximum amount of ommers is 2 per block and
    there cannot be duplicate ommers in a block. Many of the other ommer
    constraints are listed in the in-line comments of this function.

    Parameters
    ----------
    ommers :
        List of ommers mentioned in the current block.
    block_header:
        The header of current block.
    chain :
        History and current state.

    """
    block_hash = keccak256(rlp.encode(block_header))
    if keccak256(rlp.encode(ommers)) != block_header.ommers_hash:
        raise InvalidBlock

    if len(ommers) == 0:
        # Nothing to validate
        return

    # Check that each ommer satisfies the constraints of a header
    for ommer in ommers:
        if Uint(1) > ommer.number or ommer.number >= block_header.number:
            raise InvalidBlock
        validate_header(chain, ommer)
    if len(ommers) > 2:
        raise InvalidBlock

    ommers_hashes = [keccak256(rlp.encode(ommer)) for ommer in ommers]
    if len(ommers_hashes) != len(set(ommers_hashes)):
        raise InvalidBlock

    recent_canonical_blocks = chain.blocks[-(MAX_OMMER_DEPTH + Uint(1)) :]
    recent_canonical_block_hashes = {
        keccak256(rlp.encode(block.header))
        for block in recent_canonical_blocks
    }
    recent_ommers_hashes: Set[Hash32] = set()
    for block in recent_canonical_blocks:
        recent_ommers_hashes = recent_ommers_hashes.union(
            {keccak256(rlp.encode(ommer)) for ommer in block.ommers}
        )

    for ommer_index, ommer in enumerate(ommers):
        ommer_hash = ommers_hashes[ommer_index]
        if ommer_hash == block_hash:
            raise InvalidBlock
        if ommer_hash in recent_canonical_block_hashes:
            raise InvalidBlock
        if ommer_hash in recent_ommers_hashes:
            raise InvalidBlock

        # Ommer age with respect to the current block. For example, an age of
        # 1 indicates that the ommer is a sibling of previous block.
        ommer_age = block_header.number - ommer.number
        if Uint(1) > ommer_age or ommer_age > MAX_OMMER_DEPTH:
            raise InvalidBlock
        if ommer.parent_hash not in recent_canonical_block_hashes:
            raise InvalidBlock
        if ommer.parent_hash == block_header.parent_hash:
            raise InvalidBlock


def pay_rewards(
    block_env: vm.BlockEnvironment,
    ommers: Tuple[Header, ...],
) -> None:
    """
    Pay rewards to the block miner as well as the ommers miners.

    The miner of the canonical block is rewarded with the predetermined
    block reward, ``BLOCK_REWARD``, plus a variable award based off of the
    number of ommer blocks that were mined around the same time, and included
    in the canonical block's header. An ommer block is a block that wasn't
    added to the canonical blockchain because it wasn't validated as fast as
    the accepted block but was mined at the same time. Although not all blocks
    that are mined are added to the canonical chain, miners are still paid a
    reward for their efforts. This reward is called an ommer reward and is
    calculated based on the number associated with the ommer block that they
    mined.

    Parameters
    ----------
    block_env :
        The block scoped environment.
    ommers :
        List of ommers mentioned in the current block.

    """
    rewards_state = TransactionState(parent=block_env.state)
    ommer_count = U256(len(ommers))
    miner_reward = BLOCK_REWARD + (ommer_count * (BLOCK_REWARD // U256(32)))
    create_ether(rewards_state, block_env.coinbase, miner_reward)

    for ommer in ommers:
        # Ommer age with respect to the current block.
        ommer_age = U256(block_env.number - ommer.number)
        ommer_miner_reward = ((U256(8) - ommer_age) * BLOCK_REWARD) // U256(8)
        create_ether(rewards_state, ommer.coinbase, ommer_miner_reward)

    incorporate_tx_into_block(rewards_state)


def process_transaction(
    block_env: vm.BlockEnvironment,
    block_output: vm.BlockOutput,
    tx: Transaction,
    index: Uint,
) -> None:
    """
    Execute a transaction against the provided environment.

    This function processes the actions needed to execute a transaction.
    It decrements the sender's account balance after calculating the gas fee
    and refunds them the proper amount after execution. Calling contracts,
    deploying code, and incrementing nonces are all examples of actions that
    happen within this function or from a call made within this function.

    Accounts that are marked for deletion are processed and destroyed after
    execution.

    Parameters
    ----------
    block_env :
        Environment for the Ethereum Virtual Machine.
    block_output :
        The block output for the current block.
    tx :
        Transaction to execute.
    index:
        Index of the transaction in the block.

    """
    tx_state = TransactionState(parent=block_env.state)

    trie_set(block_output.transactions_trie, rlp.encode(Uint(index)), tx)
    intrinsic_gas = validate_transaction(tx)

    sender = check_transaction(
        block_env=block_env,
        block_output=block_output,
        tx=tx,
        tx_state=tx_state,
    )

    sender_account = get_account(tx_state, sender)

    gas = tx.gas - intrinsic_gas
    increment_nonce(tx_state, sender)

    gas_fee = tx.gas * tx.gas_price
    sender_balance_after_gas_fee = Uint(sender_account.balance) - gas_fee
    set_account_balance(tx_state, sender, U256(sender_balance_after_gas_fee))

    tx_env = vm.TransactionEnvironment(
        origin=sender,
        gas_price=tx.gas_price,
        gas=gas,
        state=tx_state,
        index_in_block=index,
        tx_hash=get_transaction_hash(tx),
    )

    message = prepare_message(block_env, tx_env, tx)

    tx_output = process_message_call(message)

    tx_gas_used_before_refund = tx.gas - tx_output.gas_left
    tx_gas_refund = min(
        tx_gas_used_before_refund // Uint(2), Uint(tx_output.refund_counter)
    )
    tx_gas_used_after_refund = tx_gas_used_before_refund - tx_gas_refund
    tx_gas_left = tx.gas - tx_gas_used_after_refund
    gas_refund_amount = tx_gas_left * tx.gas_price

    transaction_fee = tx_gas_used_after_refund * tx.gas_price

    # refund gas
    create_ether(tx_state, sender, U256(gas_refund_amount))

    # transfer miner fees
    coinbase_balance_after_mining_fee = get_account(
        tx_state, block_env.coinbase
    ).balance + U256(transaction_fee)
    if coinbase_balance_after_mining_fee != 0:
        set_account_balance(
            tx_state,
            block_env.coinbase,
            coinbase_balance_after_mining_fee,
        )
    elif account_exists_and_is_empty(tx_state, block_env.coinbase):
        destroy_account(tx_state, block_env.coinbase)

    for address in tx_output.accounts_to_delete:
        destroy_account(tx_state, address)

    destroy_touched_empty_accounts(tx_state, tx_output.touched_accounts)

    block_output.block_gas_used += tx_gas_used_after_refund

    receipt = make_receipt(
        tx_output.error, block_output.block_gas_used, tx_output.logs
    )

    receipt_key = rlp.encode(Uint(index))
    block_output.receipt_keys += (receipt_key,)

    trie_set(
        block_output.receipts_trie,
        receipt_key,
        receipt,
    )

    block_output.block_logs += tx_output.logs

    incorporate_tx_into_block(tx_state)


def check_gas_limit(gas_limit: Uint, parent_gas_limit: Uint) -> bool:
    """
    Validates the gas limit for a block.

    The bounds of the gas limit, ``max_adjustment_delta``, is set as the
    quotient of the parent block's gas limit and the
    ``LIMIT_ADJUSTMENT_FACTOR``. Therefore, if the gas limit that is passed
    through as a parameter is greater than or equal to the *sum* of the
    parent's gas and the adjustment delta then the limit for gas is too high
    and fails this function's check. Similarly, if the limit is less than or
    equal to the *difference* of the parent's gas and the adjustment delta *or*
    the predefined ``LIMIT_MINIMUM`` then this function's check fails because
    the gas limit doesn't allow for a sufficient or reasonable amount of gas to
    be used on a block.

    Parameters
    ----------
    gas_limit :
        Gas limit to validate.

    parent_gas_limit :
        Gas limit of the parent block.

    Returns
    -------
    check : `bool`
        True if gas limit constraints are satisfied, False otherwise.

    """
    max_adjustment_delta = parent_gas_limit // GasCosts.LIMIT_ADJUSTMENT_FACTOR
    if gas_limit >= parent_gas_limit + max_adjustment_delta:
        return False
    if gas_limit <= parent_gas_limit - max_adjustment_delta:
        return False
    if gas_limit < GasCosts.LIMIT_MINIMUM:
        return False

    return True


def calculate_block_difficulty(
    block_number: Uint,
    block_timestamp: U256,
    parent_timestamp: U256,
    parent_difficulty: Uint,
    parent_has_ommers: bool,
) -> Uint:
    """
    Computes difficulty of a block using its header and parent header.

    The difficulty is determined by the time the block was created after its
    parent. The ``offset`` is calculated using the parent block's difficulty,
    ``parent_difficulty``, and the timestamp between blocks. This offset is
    then added to the parent difficulty and is stored as the ``difficulty``
    variable. If the time between the block and its parent is too short, the
    offset will result in a positive number thus making the sum of
    ``parent_difficulty`` and ``offset`` to be a greater value in order to
    avoid mass forking. But, if the time is long enough, then the offset
    results in a negative value making the block less difficult than
    its parent.

    The base standard for a block's difficulty is the predefined value
    set for the genesis block since it has no parent. So, a block
    can't be less difficult than the genesis block, therefore each block's
    difficulty is set to the maximum value between the calculated
    difficulty and the ``MINIMUM_DIFFICULTY``.

    Parameters
    ----------
    block_number :
        Block number of the block.
    block_timestamp :
        Timestamp of the block.
    parent_timestamp :
        Timestamp of the parent block.
    parent_difficulty :
        difficulty of the parent block.
    parent_has_ommers:
        does the parent have ommers.

    Returns
    -------
    difficulty : `ethereum.base_types.Uint`
        Computed difficulty for a block.

    """
    offset = (
        int(parent_difficulty)
        // 2048
        * max(
            (2 if parent_has_ommers else 1)
            - int(block_timestamp - parent_timestamp) // 9,
            -99,
        )
    )
    difficulty = int(parent_difficulty) + offset
    # Historical Note: The difficulty bomb was not present in Ethereum at the
    # start of Frontier, but was added shortly after launch. However since the
    # bomb has no effect prior to block 200000 we pretend it existed from
    # genesis.
    # See https://github.com/ethereum/go-ethereum/pull/1588
    num_bomb_periods = ((int(block_number) - BOMB_DELAY_BLOCKS) // 100000) - 2
    if num_bomb_periods >= 0:
        difficulty += 2**num_bomb_periods

    # Some clients raise the difficulty to `MINIMUM_DIFFICULTY` prior to adding
    # the bomb. This bug does not matter because the difficulty is always much
    # greater than `MINIMUM_DIFFICULTY` on Mainnet.
    return Uint(max(difficulty, int(MINIMUM_DIFFICULTY)))

```


================================================================================
FILE: ethereum/forks/muir_glacier/state_tracker.py
================================================================================

```python
"""
State Tracking for Block Execution.

Track state changes on top of a read-only ``PreState``.  At block end,
accumulated diffs feed into
``PreState.compute_state_root_and_trie_changes()``.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Replace the mutable ``State`` class with lightweight state trackers that
record diffs.  ``BlockState`` accumulates committed transaction
changes across a block.  ``TransactionState`` tracks in-flight changes
within a single transaction and supports copy-on-write rollback.
"""

from dataclasses import dataclass, field
from typing import Callable, Dict, Optional, Set, Tuple, final

from ethereum_types.bytes import Bytes, Bytes32
from ethereum_types.frozen import modify
from ethereum_types.numeric import U256, Uint

from ethereum.crypto.hash import Hash32, keccak256
from ethereum.state import (
    EMPTY_ACCOUNT,
    EMPTY_CODE_HASH,
    Account,
    Address,
    BlockDiff,
    PreState,
)


@final
@dataclass
class BlockState:
    """
    Accumulate committed transaction-level changes across a block.

    Read chain: block writes -> pre_state.

    ``storage_clears`` records addresses whose storage was wiped by
    a pre-EIP-6780 ``SELFDESTRUCT`` earlier in the block, so later
    reads must not fall back to ``pre_state`` storage.
    """

    pre_state: PreState
    account_writes: Dict[Address, Optional[Account]] = field(
        default_factory=dict
    )
    storage_writes: Dict[Address, Dict[Bytes32, U256]] = field(
        default_factory=dict
    )
    code_writes: Dict[Hash32, Bytes] = field(default_factory=dict)
    storage_clears: Set[Address] = field(default_factory=set)


@final
@dataclass
class TransactionState:
    """
    Track in-flight state changes within a single transaction.

    Read chain: tx writes -> block writes -> pre_state.
    """

    parent: BlockState
    account_writes: Dict[Address, Optional[Account]] = field(
        default_factory=dict
    )
    storage_writes: Dict[Address, Dict[Bytes32, U256]] = field(
        default_factory=dict
    )
    code_writes: Dict[Hash32, Bytes] = field(default_factory=dict)
    created_accounts: Set[Address] = field(default_factory=set)
    storage_clears: Set[Address] = field(default_factory=set)
    transient_storage: Dict[Tuple[Address, Bytes32], U256] = field(
        default_factory=dict
    )


def get_account_optional(
    tx_state: TransactionState, address: Address
) -> Optional[Account]:
    """
    Get the ``Account`` object at an address. Return ``None`` (rather than
    ``EMPTY_ACCOUNT``) if there is no account at the address.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address to look up.

    Returns
    -------
    account : ``Optional[Account]``
        Account at address.

    """
    if address in tx_state.account_writes:
        return tx_state.account_writes[address]
    if address in tx_state.parent.account_writes:
        return tx_state.parent.account_writes[address]
    return tx_state.parent.pre_state.get_account_optional(address)


def get_account(tx_state: TransactionState, address: Address) -> Account:
    """
    Get the ``Account`` object at an address. Return ``EMPTY_ACCOUNT``
    if there is no account at the address.

    Use ``get_account_optional()`` if you care about the difference
    between a non-existent account and ``EMPTY_ACCOUNT``.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address to look up.

    Returns
    -------
    account : ``Account``
        Account at address.

    """
    account = get_account_optional(tx_state, address)
    if account is None:
        return EMPTY_ACCOUNT
    else:
        return account


def get_code(tx_state: TransactionState, code_hash: Hash32) -> Bytes:
    """
    Get the bytecode for a given code hash.

    Read chain: tx code_writes -> block code_writes -> pre_state.

    Parameters
    ----------
    tx_state :
        The transaction state.
    code_hash :
        Hash of the code to look up.

    Returns
    -------
    code : ``Bytes``
        The bytecode.

    """
    if code_hash == EMPTY_CODE_HASH:
        return b""
    if code_hash in tx_state.code_writes:
        return tx_state.code_writes[code_hash]
    if code_hash in tx_state.parent.code_writes:
        return tx_state.parent.code_writes[code_hash]
    return tx_state.parent.pre_state.get_code(code_hash)


def get_storage(
    tx_state: TransactionState, address: Address, key: Bytes32
) -> U256:
    """
    Get a value at a storage key on an account. Return ``U256(0)`` if
    the storage key has not been set previously.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account.
    key :
        Key to look up.

    Returns
    -------
    value : ``U256``
        Value at the key.

    """
    if address in tx_state.storage_writes:
        if key in tx_state.storage_writes[address]:
            return tx_state.storage_writes[address][key]
    if address in tx_state.storage_clears:
        return U256(0)
    if address in tx_state.parent.storage_writes:
        if key in tx_state.parent.storage_writes[address]:
            return tx_state.parent.storage_writes[address][key]
    if address in tx_state.parent.storage_clears:
        return U256(0)
    return tx_state.parent.pre_state.get_storage(address, key)


def get_storage_original(
    tx_state: TransactionState, address: Address, key: Bytes32
) -> U256:
    """
    Get the original value in a storage slot i.e. the value before the
    current transaction began. Read from block-level writes, then
    pre_state. Return ``U256(0)`` for accounts created in the current
    transaction.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account to read the value from.
    key :
        Key of the storage slot.

    """
    if address in tx_state.created_accounts:
        return U256(0)
    if address in tx_state.parent.storage_writes:
        if key in tx_state.parent.storage_writes[address]:
            return tx_state.parent.storage_writes[address][key]
    if address in tx_state.parent.storage_clears:
        return U256(0)
    return tx_state.parent.pre_state.get_storage(address, key)


def get_transient_storage(
    tx_state: TransactionState, address: Address, key: Bytes32
) -> U256:
    """
    Get a value at a storage key on an account from transient storage.
    Return ``U256(0)`` if the storage key has not been set previously.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account.
    key :
        Key to look up.

    Returns
    -------
    value : ``U256``
        Value at the key.

    """
    return tx_state.transient_storage.get((address, key), U256(0))


def account_exists(tx_state: TransactionState, address: Address) -> bool:
    """
    Check if an account exists in the state trie.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account that needs to be checked.

    Returns
    -------
    account_exists : ``bool``
        True if account exists in the state trie, False otherwise.

    """
    return get_account_optional(tx_state, address) is not None


def account_deployable(tx_state: TransactionState, address: Address) -> bool:
    """
    Check if an account's code can be written to.
    """
    account = get_account(tx_state, address)
    if account.nonce != Uint(0) or account.code_hash != EMPTY_CODE_HASH:
        return False

    if account_has_storage(tx_state, address):
        return False

    return True


def account_has_storage(tx_state: TransactionState, address: Address) -> bool:
    """
    Check if an account has storage.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account that needs to be checked.

    Returns
    -------
    has_storage : ``bool``
        True if the account has storage, False otherwise.

    """
    if tx_state.storage_writes.get(address):
        return True
    if address in tx_state.storage_clears:
        return False
    if tx_state.parent.storage_writes.get(address):
        return True
    if address in tx_state.parent.storage_clears:
        return False
    return tx_state.parent.pre_state.account_has_storage(address)


def account_exists_and_is_empty(
    tx_state: TransactionState, address: Address
) -> bool:
    """
    Check if an account exists and has zero nonce, empty code and zero
    balance.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account that needs to be checked.

    Returns
    -------
    exists_and_is_empty : ``bool``
        True if an account exists and has zero nonce, empty code and
        zero balance, False otherwise.

    """
    account = get_account_optional(tx_state, address)
    return (
        account is not None
        and account.nonce == Uint(0)
        and account.code_hash == EMPTY_CODE_HASH
        and account.balance == 0
    )


def is_account_alive(tx_state: TransactionState, address: Address) -> bool:
    """
    Check whether an account is both in the state and non-empty.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account that needs to be checked.

    Returns
    -------
    is_alive : ``bool``
        True if the account is alive.

    """
    account = get_account_optional(tx_state, address)
    return account is not None and account != EMPTY_ACCOUNT


def set_account(
    tx_state: TransactionState,
    address: Address,
    account: Optional[Account],
) -> None:
    """
    Set the ``Account`` object at an address. Setting to ``None``
    deletes the account (but not its storage, see
    ``destroy_account()``).

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address to set.
    account :
        Account to set at address.

    """
    tx_state.account_writes[address] = account


def set_storage(
    tx_state: TransactionState,
    address: Address,
    key: Bytes32,
    value: U256,
) -> None:
    """
    Set a value at a storage key on an account.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account.
    key :
        Key to set.
    value :
        Value to set at the key.

    """
    assert get_account_optional(tx_state, address) is not None
    if address not in tx_state.storage_writes:
        tx_state.storage_writes[address] = {}
    tx_state.storage_writes[address][key] = value


def destroy_account(tx_state: TransactionState, address: Address) -> None:
    """
    Completely remove the account at ``address`` and all of its storage.

    This function is made available exclusively for the ``SELFDESTRUCT``
    opcode. It is expected that ``SELFDESTRUCT`` will be disabled in a
    future hardfork and this function will be removed. Only supports same
    transaction destruction.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of account to destroy.

    """
    destroy_storage(tx_state, address)
    set_account(tx_state, address, None)


def destroy_storage(tx_state: TransactionState, address: Address) -> None:
    """
    Completely remove the storage at ``address``.

    Only supports same transaction destruction.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of account whose storage is to be deleted.

    """
    if address in tx_state.storage_writes:
        del tx_state.storage_writes[address]
    tx_state.storage_clears.add(address)


def mark_account_created(tx_state: TransactionState, address: Address) -> None:
    """
    Mark an account as having been created in the current transaction.
    This information is used by ``get_storage_original()`` to handle an
    obscure edgecase, and to respect the constraints added to
    SELFDESTRUCT by EIP-6780.

    The marker is not removed even if the account creation reverts.
    Since the account cannot have had code prior to its creation and
    can't call ``get_storage_original()``, this is harmless.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account that has been created.

    """
    tx_state.created_accounts.add(address)


def set_transient_storage(
    tx_state: TransactionState,
    address: Address,
    key: Bytes32,
    value: U256,
) -> None:
    """
    Set a value at a storage key on an account in transient storage.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account.
    key :
        Key to set.
    value :
        Value to set at the key.

    """
    if value == U256(0):
        tx_state.transient_storage.pop((address, key), None)
    else:
        tx_state.transient_storage[(address, key)] = value


def modify_state(
    tx_state: TransactionState,
    address: Address,
    f: Callable[[Account], None],
) -> None:
    """
    Modify an ``Account`` in the state.
    """
    set_account(tx_state, address, modify(get_account(tx_state, address), f))


def move_ether(
    tx_state: TransactionState,
    sender_address: Address,
    recipient_address: Address,
    amount: U256,
) -> None:
    """
    Move funds between accounts.

    Parameters
    ----------
    tx_state :
        The transaction state.
    sender_address :
        Address of the sender.
    recipient_address :
        Address of the recipient.
    amount :
        The amount to transfer.

    """

    def reduce_sender_balance(sender: Account) -> None:
        if sender.balance < amount:
            raise AssertionError
        sender.balance -= amount

    def increase_recipient_balance(recipient: Account) -> None:
        recipient.balance += amount

    modify_state(tx_state, sender_address, reduce_sender_balance)
    modify_state(tx_state, recipient_address, increase_recipient_balance)


def create_ether(
    tx_state: TransactionState, address: Address, amount: U256
) -> None:
    """
    Add newly created ether to an account.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account to which ether is added.
    amount :
        The amount of ether to be added to the account of interest.

    """

    def increase_balance(account: Account) -> None:
        account.balance += amount

    modify_state(tx_state, address, increase_balance)


def set_account_balance(
    tx_state: TransactionState, address: Address, amount: U256
) -> None:
    """
    Set the balance of an account.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account whose balance needs to be set.
    amount :
        The amount that needs to be set in the balance.

    """

    def set_balance(account: Account) -> None:
        account.balance = amount

    modify_state(tx_state, address, set_balance)


def increment_nonce(tx_state: TransactionState, address: Address) -> None:
    """
    Increment the nonce of an account.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account whose nonce needs to be incremented.

    """

    def increase_nonce(sender: Account) -> None:
        sender.nonce += Uint(1)

    modify_state(tx_state, address, increase_nonce)


def set_code(
    tx_state: TransactionState, address: Address, code: Bytes
) -> None:
    """
    Set Account code.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account whose code needs to be updated.
    code :
        The bytecode that needs to be set.

    """
    code_hash = keccak256(code)
    if code_hash != EMPTY_CODE_HASH:
        tx_state.code_writes[code_hash] = code

    def write_code_hash(sender: Account) -> None:
        sender.code_hash = code_hash

    modify_state(tx_state, address, write_code_hash)


# -- Snapshot / Rollback ---------------------------------------------------


def copy_tx_state(tx_state: TransactionState) -> TransactionState:
    """
    Create a snapshot of the transaction state for rollback.

    Deep-copy writes and transient storage.  The parent reference and
    ``created_accounts`` are shared (not rolled back).

    Parameters
    ----------
    tx_state :
        The transaction state to snapshot.

    Returns
    -------
    snapshot : ``TransactionState``
        A copy of the transaction state.

    """
    return TransactionState(
        parent=tx_state.parent,
        account_writes=dict(tx_state.account_writes),
        storage_writes={
            addr: dict(slots)
            for addr, slots in tx_state.storage_writes.items()
        },
        code_writes=dict(tx_state.code_writes),
        created_accounts=tx_state.created_accounts,
        storage_clears=set(tx_state.storage_clears),
        transient_storage=dict(tx_state.transient_storage),
    )


def restore_tx_state(
    tx_state: TransactionState, snapshot: TransactionState
) -> None:
    """
    Restore transaction state from a snapshot (rollback on failure).

    Parameters
    ----------
    tx_state :
        The transaction state to restore.
    snapshot :
        The snapshot to restore from.

    """
    tx_state.account_writes = snapshot.account_writes
    tx_state.storage_writes = snapshot.storage_writes
    tx_state.code_writes = snapshot.code_writes
    tx_state.storage_clears = snapshot.storage_clears
    tx_state.transient_storage = snapshot.transient_storage


# -- Lifecycle --------------------------------------------------------------


def incorporate_tx_into_block(tx_state: TransactionState) -> None:
    """
    Merge transaction writes into the block state and clear for reuse.

    Parameters
    ----------
    tx_state :
        The transaction state to commit.

    """
    block = tx_state.parent

    for address, account in tx_state.account_writes.items():
        block.account_writes[address] = account

    for address in tx_state.storage_clears:
        block.storage_clears.add(address)
        block.storage_writes.pop(address, None)

    for address, slots in tx_state.storage_writes.items():
        if address not in block.storage_writes:
            block.storage_writes[address] = {}
        block.storage_writes[address].update(slots)

    block.code_writes.update(tx_state.code_writes)

    tx_state.account_writes.clear()
    tx_state.storage_writes.clear()
    tx_state.code_writes.clear()
    tx_state.created_accounts.clear()
    tx_state.storage_clears.clear()
    tx_state.transient_storage.clear()


def extract_block_diff(block_state: BlockState) -> BlockDiff:
    """
    Extract account, storage, and code diff from the block state.

    Parameters
    ----------
    block_state :
        The block state.

    Returns
    -------
    diff : `BlockDiff`
        Account, storage, and code changes accumulated during block execution.

    """
    return BlockDiff(
        account_changes=block_state.account_writes,
        storage_changes=block_state.storage_writes,
        code_changes=block_state.code_writes,
        storage_clears=block_state.storage_clears,
    )


def destroy_touched_empty_accounts(
    tx_state: TransactionState, touched_accounts: Set[Address]
) -> None:
    """
    Destroy all touched accounts that are empty.

    Parameters
    ----------
    tx_state :
        The transaction state.
    touched_accounts :
        All the accounts that have been touched in the current transaction.

    """
    for address in touched_accounts:
        if account_exists_and_is_empty(tx_state, address):
            destroy_account(tx_state, address)


def touch_account(tx_state: TransactionState, address: Address) -> None:
    """
    Initialize an account to state.

    Parameters
    ----------
    tx_state :
        The transaction state.
    address :
        Address of the account that needs to be initialized.

    """
    if not account_exists(tx_state, address):
        set_account(tx_state, address, EMPTY_ACCOUNT)

```


================================================================================
FILE: ethereum/forks/muir_glacier/transactions.py
================================================================================

```python
"""
Transactions are atomic units of work created externally to Ethereum and
submitted to be executed. If Ethereum is viewed as a state machine,
transactions are the events that move between states.
"""

from dataclasses import dataclass
from typing import final

from ethereum_rlp import rlp
from ethereum_types.bytes import Bytes, Bytes0
from ethereum_types.frozen import slotted_freezable
from ethereum_types.numeric import U64, U256, Uint, ulen

from ethereum.crypto.elliptic_curve import SECP256K1N, secp256k1_recover
from ethereum.crypto.hash import Hash32, keccak256
from ethereum.exceptions import (
    InsufficientTransactionGasError,
    InvalidSignatureError,
    NonceOverflowError,
)
from ethereum.state import Address


@final
@slotted_freezable
@dataclass
class Transaction:
    """
    Atomic operation performed on the block chain.
    """

    nonce: U256
    """
    A scalar value equal to the number of transactions sent by the sender.
    """

    gas_price: Uint
    """
    The price of gas for this transaction, in wei.
    """

    gas: Uint
    """
    The maximum amount of gas that can be used by this transaction.
    """

    to: Bytes0 | Address
    """
    The address of the recipient. If empty, the transaction is a contract
    creation.
    """

    value: U256
    """
    The amount of ether (in wei) to send with this transaction.
    """

    data: Bytes
    """
    The data payload of the transaction, which can be used to call functions
    on contracts or to create new contracts.
    """

    v: U256
    """
    The recovery id of the signature.
    """

    r: U256
    """
    The first part of the signature.
    """

    s: U256
    """
    The second part of the signature.
    """


def validate_transaction(tx: Transaction) -> Uint:
    """
    Verifies a transaction.

    The gas in a transaction gets used to pay for the intrinsic cost of
    operations, therefore if there is insufficient gas then it would not
    be possible to execute a transaction and it will be declared invalid.

    Additionally, the nonce of a transaction must not equal or exceed the
    limit defined in [EIP-2681].
    In practice, defining the limit as ``2**64-1`` has no impact because
    sending ``2**64-1`` transactions is improbable. It's not strictly
    impossible though, ``2**64-1`` transactions is the entire capacity of the
    Ethereum blockchain at 2022 gas limits for a little over 22 years.

    This function takes a transaction as a parameter and returns the intrinsic
    gas cost of the transaction after validation. It throws an
    `InsufficientTransactionGasError` exception if the transaction does not
    provide enough gas to cover the intrinsic cost, and a `NonceOverflowError`
    exception if the nonce is greater than `2**64 - 2`.

    [EIP-2681]: https://eips.ethereum.org/EIPS/eip-2681
    """
    intrinsic_gas = calculate_intrinsic_cost(tx)
    if intrinsic_gas > tx.gas:
        raise InsufficientTransactionGasError("Insufficient gas")
    if U256(tx.nonce) >= U256(U64.MAX_VALUE):
        raise NonceOverflowError("Nonce too high")
    return intrinsic_gas


def calculate_intrinsic_cost(tx: Transaction) -> Uint:
    """
    Calculates the gas that is charged before execution is started.

    The intrinsic cost of the transaction is charged before execution has
    begun. Functions/operations in the EVM cost money to execute so this
    intrinsic cost is for the operations that need to be paid for as part of
    the transaction. Data transfer, for example, is part of this intrinsic
    cost. It costs ether to send data over the wire and that ether is
    accounted for in the intrinsic cost calculated in this function. This
    intrinsic cost must be calculated and paid for before execution in order
    for all operations to be implemented.

    The intrinsic cost includes:
    1. Base cost (`TX_BASE`)
    2. Cost for data (zero and non-zero bytes)
    3. Cost for contract creation (if applicable)

    This function takes a transaction as a parameter and returns the intrinsic
    gas cost of the transaction.
    """
    from .vm.gas import GasCosts

    num_zeros = Uint(tx.data.count(0))
    num_non_zeros = ulen(tx.data) - num_zeros
    data_cost = (
        num_zeros * GasCosts.TX_DATA_PER_ZERO
        + num_non_zeros * GasCosts.TX_DATA_PER_NON_ZERO
    )

    if tx.to == Bytes0(b""):
        create_cost = GasCosts.TX_CREATE
    else:
        create_cost = Uint(0)

    return GasCosts.TX_BASE + data_cost + create_cost


def chain_id(tx: Transaction) -> None | U64:
    """
    Extract the chain identifier from a transaction. See [EIP-155].

    [EIP-155]: https://eips.ethereum.org/EIPS/eip-155
    """
    if tx.v == 27 or tx.v == 28:
        return None
    if tx.v < U256(35):
        raise InvalidSignatureError("bad v")
    return U64((tx.v - U256(35)) >> U256(1))


def recover_sender(tx: Transaction) -> Address:
    """
    Extracts the sender address from a transaction.

    The v, r, and s values are the three parts that make up the signature
    of a transaction. In order to recover the sender of a transaction the two
    components needed are the signature (``v``, ``r``, and ``s``) and the
    signing hash of the transaction. The sender's public key can be obtained
    with these two values and therefore the sender address can be retrieved.

    This function takes chain_id and a transaction as parameters and returns
    the address of the sender of the transaction. It raises an
    `InvalidSignatureError` if the signature values (r, s, v) are invalid.
    """
    v, r, s = tx.v, tx.r, tx.s
    if U256(0) >= r or r >= SECP256K1N:
        raise InvalidSignatureError("bad r")
    if U256(0) >= s or s > SECP256K1N // U256(2):
        raise InvalidSignatureError("bad s")

    if v == 27 or v == 28:
        public_key = secp256k1_recover(
            r, s, v - U256(27), signing_hash_pre155(tx)
        )
    else:
        assert v >= U256(35), "call chain_id before recover_sender"
        tx_chain_id = U64((v - U256(35)) >> U256(1))
        v = (v - U256(35)) & U256(1)
        public_key = secp256k1_recover(
            r, s, v, signing_hash_155(tx, tx_chain_id)
        )

    return Address(keccak256(public_key)[12:32])


def signing_hash_pre155(tx: Transaction) -> Hash32:
    """
    Compute the hash of a transaction used in a legacy (pre [EIP-155])
    signature.

    This function takes a transaction as a parameter and returns the
    signing hash of the transaction.

    [EIP-155]: https://eips.ethereum.org/EIPS/eip-155
    """
    return keccak256(
        rlp.encode(
            (
                tx.nonce,
                tx.gas_price,
                tx.gas,
                tx.to,
                tx.value,
                tx.data,
            )
        )
    )


def signing_hash_155(tx: Transaction, chain_id: U64) -> Hash32:
    """
    Compute the hash of a transaction used in a [EIP-155] signature.

    This function takes a transaction and chain ID as parameters and returns
    the hash of the transaction used in a [EIP-155] signature.

    [EIP-155]: https://eips.ethereum.org/EIPS/eip-155
    """
    return keccak256(
        rlp.encode(
            (
                tx.nonce,
                tx.gas_price,
                tx.gas,
                tx.to,
                tx.value,
                tx.data,
                chain_id,
                Uint(0),
                Uint(0),
            )
        )
    )


def get_transaction_hash(tx: Transaction) -> Hash32:
    """
    Compute the hash of a transaction.

    This function takes a transaction as a parameter and returns the
    hash of the transaction.
    """
    return keccak256(rlp.encode(tx))

```


================================================================================
FILE: ethereum/forks/muir_glacier/utils/__init__.py
================================================================================

```python
"""
Utility functions unique to this particular fork.
"""

```


================================================================================
FILE: ethereum/forks/muir_glacier/utils/address.py
================================================================================

```python
"""
Hardfork Utility Functions For Addresses.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Address specific functions used in this muir_glacier version of
specification.
"""

from ethereum_rlp import rlp
from ethereum_types.bytes import Bytes, Bytes32
from ethereum_types.numeric import U256, Uint

from ethereum.crypto.hash import keccak256
from ethereum.state import Address
from ethereum.utils.byte import left_pad_zero_bytes


def to_address_masked(data: Uint | U256) -> Address:
    """
    Convert a Uint or U256 value to a valid address (20 bytes).

    Parameters
    ----------
    data :
        The numeric value to be converted to address.

    Returns
    -------
    address : `Address`
        The obtained address.

    """
    return Address(data.to_be_bytes32()[-20:])


def compute_contract_address(address: Address, nonce: Uint) -> Address:
    """
    Computes address of the new account that needs to be created.

    Parameters
    ----------
    address :
        The address of the account that wants to create the new account.
    nonce :
        The transaction count of the account that wants to create the new
        account.

    Returns
    -------
    address: `Address`
        The computed address of the new account.

    """
    computed_address = keccak256(rlp.encode([address, nonce]))
    canonical_address = computed_address[-20:]
    padded_address = left_pad_zero_bytes(canonical_address, 20)
    return Address(padded_address)


def compute_create2_contract_address(
    address: Address, salt: Bytes32, call_data: Bytes
) -> Address:
    """
    Computes address of the new account that needs to be created, which is
    based on the sender address, salt and the call data as well.

    Parameters
    ----------
    address :
        The address of the account that wants to create the new account.
    salt :
        Address generation salt.
    call_data :
        The code of the new account which is to be created.

    Returns
    -------
    address: `ethereum.forks.muir_glacier.fork_types.Address`
        The computed address of the new account.

    """
    preimage = b"\xff" + address + salt + keccak256(call_data)
    computed_address = keccak256(preimage)
    canonical_address = computed_address[-20:]
    padded_address = left_pad_zero_bytes(canonical_address, 20)

    return Address(padded_address)

```


================================================================================
FILE: ethereum/forks/muir_glacier/utils/hexadecimal.py
================================================================================

```python
"""
Utility Functions For Hexadecimal Strings.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Hexadecimal utility functions used in this specification, specific to
Muir Glacier types.
"""

from ethereum_types.bytes import Bytes

from ethereum.state import Address, Root
from ethereum.utils.hexadecimal import remove_hex_prefix


def hex_to_root(hex_string: str) -> Root:
    """
    Convert hex string to trie root.

    Parameters
    ----------
    hex_string :
        The hexadecimal string to be converted to trie root.

    Returns
    -------
    root : `Root`
        Trie root obtained from the given hexadecimal string.

    """
    return Root(Bytes.fromhex(remove_hex_prefix(hex_string)))


def hex_to_address(hex_string: str) -> Address:
    """
    Convert hex string to Address (20 bytes).

    Parameters
    ----------
    hex_string :
        The hexadecimal string to be converted to Address.

    Returns
    -------
    address : `Address`
        The address obtained from the given hexadecimal string.

    """
    return Address(Bytes.fromhex(remove_hex_prefix(hex_string).rjust(40, "0")))

```


================================================================================
FILE: ethereum/forks/muir_glacier/utils/message.py
================================================================================

```python
"""
Hardfork Utility Functions For The Message Data-structure.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Message specific functions used in this muir_glacier version of
specification.
"""

from ethereum_types.bytes import Bytes, Bytes0
from ethereum_types.numeric import Uint

from ethereum.state import Address

from ..state_tracker import get_account, get_code
from ..transactions import Transaction
from ..vm import BlockEnvironment, Message, TransactionEnvironment
from .address import compute_contract_address


def prepare_message(
    block_env: BlockEnvironment,
    tx_env: TransactionEnvironment,
    tx: Transaction,
) -> Message:
    """
    Execute a transaction against the provided environment.

    Parameters
    ----------
    block_env :
        Environment for the Ethereum Virtual Machine.
    tx_env :
        Environment for the transaction.
    tx :
        Transaction to be executed.

    Returns
    -------
    message: `ethereum.forks.muir_glacier.vm.Message`
        Items containing contract creation or message call specific data.

    """
    if isinstance(tx.to, Bytes0):
        current_target = compute_contract_address(
            tx_env.origin,
            get_account(tx_env.state, tx_env.origin).nonce - Uint(1),
        )
        msg_data = Bytes(b"")
        code = tx.data
        code_address = None
    elif isinstance(tx.to, Address):
        current_target = tx.to
        msg_data = tx.data
        account = get_account(tx_env.state, tx.to)
        code = get_code(tx_env.state, account.code_hash)

        code_address = tx.to
    else:
        raise AssertionError("Target must be address or empty bytes")

    return Message(
        block_env=block_env,
        tx_env=tx_env,
        caller=tx_env.origin,
        target=tx.to,
        gas=tx_env.gas,
        value=tx.value,
        data=msg_data,
        code=code,
        depth=Uint(0),
        current_target=current_target,
        code_address=code_address,
        should_transfer_value=True,
        is_static=False,
        parent_evm=None,
    )

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/__init__.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM).

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

The abstract computer which runs the code stored in an
`.fork_types.Account`.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Set, Tuple, final

from ethereum_types.bytes import Bytes, Bytes0
from ethereum_types.numeric import U64, U256, Uint

from ethereum.crypto.hash import Hash32
from ethereum.exceptions import EthereumException
from ethereum.merkle_patricia_trie import Trie
from ethereum.state import Address

from ..blocks import Log, Receipt
from ..state_tracker import (
    BlockState,
    TransactionState,
    account_exists_and_is_empty,
)
from ..transactions import Transaction
from .precompiled_contracts import RIPEMD160_ADDRESS

__all__ = ("Environment", "Evm", "Message")


@final
@dataclass
class BlockEnvironment:
    """
    Items external to the virtual machine itself, provided by the environment.
    """

    chain_id: U64
    state: BlockState
    block_gas_limit: Uint
    block_hashes: List[Hash32]
    coinbase: Address
    number: Uint
    time: U256
    difficulty: Uint


@final
@dataclass
class BlockOutput:
    """
    Output from applying the block body to the present state.

    Contains the following:

    block_gas_used : `ethereum.base_types.Uint`
        Gas used for executing all transactions.
    transactions_trie : `ethereum.fork_types.Root`
        Trie of all the transactions in the block.
    receipts_trie : `ethereum.fork_types.Root`
        Trie root of all the receipts in the block.
    receipt_keys :
        Keys of all the receipts in the block.
    block_logs : `Bloom`
        Logs bloom of all the logs included in all the transactions of the
        block.
    """

    block_gas_used: Uint = Uint(0)
    transactions_trie: Trie[Bytes, Optional[Transaction]] = field(
        default_factory=lambda: Trie(secured=False, default=None)
    )
    receipts_trie: Trie[Bytes, Optional[Receipt]] = field(
        default_factory=lambda: Trie(secured=False, default=None)
    )
    receipt_keys: Tuple[Bytes, ...] = field(default_factory=tuple)
    block_logs: Tuple[Log, ...] = field(default_factory=tuple)


@final
@dataclass
class TransactionEnvironment:
    """
    Items that are used while processing a transaction.
    """

    origin: Address
    gas_price: Uint
    gas: Uint
    state: TransactionState
    index_in_block: Uint
    tx_hash: Optional[Hash32]


@final
@dataclass
class Message:
    """
    Items that are used by contract creation or message call.
    """

    block_env: BlockEnvironment
    tx_env: TransactionEnvironment
    caller: Address
    target: Bytes0 | Address
    current_target: Address
    gas: Uint
    value: U256
    data: Bytes
    code_address: Optional[Address]
    code: Bytes
    depth: Uint
    should_transfer_value: bool
    is_static: bool
    parent_evm: Optional["Evm"]


@final
@dataclass
class Evm:
    """The internal state of the virtual machine."""

    pc: Uint
    stack: List[U256]
    memory: bytearray
    code: Bytes
    gas_left: Uint
    valid_jump_destinations: Set[Uint]
    logs: Tuple[Log, ...]
    refund_counter: int
    running: bool
    message: Message
    output: Bytes
    accounts_to_delete: Set[Address]
    touched_accounts: Set[Address]
    return_data: Bytes
    error: Optional[EthereumException]


def incorporate_child_on_success(evm: Evm, child_evm: Evm) -> None:
    """
    Incorporate the state of a successful `child_evm` into the parent `evm`.

    Parameters
    ----------
    evm :
        The parent `EVM`.
    child_evm :
        The child evm to incorporate.

    """
    evm.gas_left += child_evm.gas_left
    evm.logs += child_evm.logs
    evm.refund_counter += child_evm.refund_counter
    evm.accounts_to_delete.update(child_evm.accounts_to_delete)
    evm.touched_accounts.update(child_evm.touched_accounts)
    if account_exists_and_is_empty(
        evm.message.tx_env.state, child_evm.message.current_target
    ):
        evm.touched_accounts.add(child_evm.message.current_target)


def incorporate_child_on_error(evm: Evm, child_evm: Evm) -> None:
    """
    Incorporate the state of an unsuccessful `child_evm` into the parent `evm`.

    Parameters
    ----------
    evm :
        The parent `EVM`.
    child_evm :
        The child evm to incorporate.

    """
    # In block 2675119, the empty account at 0x3 (the RIPEMD160 precompile) was
    # cleared despite running out of gas. This is an obscure edge case that can
    # only happen to a precompile.
    # According to the general rules governing clearing of empty accounts, the
    # touch should have been reverted. Due to client bugs, this event went
    # unnoticed and 0x3 has been exempted from the rule that touches are
    # reverted in order to preserve this historical behaviour.
    if RIPEMD160_ADDRESS in child_evm.touched_accounts:
        evm.touched_accounts.add(RIPEMD160_ADDRESS)
    if child_evm.message.current_target == RIPEMD160_ADDRESS:
        if account_exists_and_is_empty(
            evm.message.tx_env.state, child_evm.message.current_target
        ):
            evm.touched_accounts.add(RIPEMD160_ADDRESS)
    evm.gas_left += child_evm.gas_left

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/exceptions.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Exceptions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Exceptions which cause the EVM to halt exceptionally.
"""

from ethereum.exceptions import EthereumException


class ExceptionalHalt(EthereumException):
    """
    Indicates that the EVM has experienced an exceptional halt. This causes
    execution to immediately end with all gas being consumed.
    """


class Revert(EthereumException):
    """
    Raised by the `REVERT` opcode.

    Unlike other EVM exceptions this does not result in the consumption of all
    gas.
    """

    pass


class StackUnderflowError(ExceptionalHalt):
    """
    Occurs when a pop is executed on an empty stack.
    """

    pass


class StackOverflowError(ExceptionalHalt):
    """
    Occurs when a push is executed on a stack at max capacity.
    """

    pass


class OutOfGasError(ExceptionalHalt):
    """
    Occurs when an operation costs more than the amount of gas left in the
    frame.
    """

    pass


class InvalidOpcode(ExceptionalHalt):
    """
    Raised when an invalid opcode is encountered.
    """

    code: int

    def __init__(self, code: int) -> None:
        super().__init__(code)
        self.code = code


class InvalidJumpDestError(ExceptionalHalt):
    """
    Occurs when the destination of a jump operation doesn't meet any of the
    following criteria.

      * The jump destination is less than the length of the code.
      * The jump destination should have the `JUMPDEST` opcode (0x5B).
      * The jump destination shouldn't be part of the data corresponding to
        `PUSH-N` opcodes.
    """


class StackDepthLimitError(ExceptionalHalt):
    """
    Raised when the message depth is greater than `1024`.
    """

    pass


class WriteInStaticContext(ExceptionalHalt):
    """
    Raised when an attempt is made to modify the state while operating inside
    of a STATICCALL context.
    """

    pass


class OutOfBoundsRead(ExceptionalHalt):
    """
    Raised when an attempt was made to read data beyond the
    boundaries of the buffer.
    """

    pass


class InvalidParameter(ExceptionalHalt):
    """
    Raised when invalid parameters are passed.
    """

    pass


class AddressCollision(ExceptionalHalt):
    """
    Raised when the new contract address has a collision.
    """

    pass

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/gas.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Gas.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

EVM gas constants and calculators.
"""

from dataclasses import dataclass
from typing import Final, List, Tuple, final

from ethereum_types.numeric import U256, Uint, ulen

from ethereum.trace import GasAndRefund, evm_trace
from ethereum.utils.numeric import ceil32

from . import Evm
from .exceptions import OutOfGasError


# These values may be patched at runtime by a future gas repricing utility
class GasCosts:
    """
    Constant gas values for the EVM.
    """

    # Tiers
    BASE: Final[Uint] = Uint(2)
    VERY_LOW: Final[Uint] = Uint(3)
    LOW: Final[Uint] = Uint(5)
    MID: Final[Uint] = Uint(8)
    HIGH: Final[Uint] = Uint(10)

    # Access
    SLOAD: Final[Uint] = Uint(800)

    # Storage
    STORAGE_SET: Final[Uint] = Uint(20000)
    COLD_STORAGE_WRITE: Final[Uint] = Uint(5000)

    # Call
    CALL_VALUE: Final[Uint] = Uint(9000)
    CALL_STIPEND: Final[Uint] = Uint(2300)
    NEW_ACCOUNT: Final[Uint] = Uint(25000)

    # Contract Creation
    CODE_DEPOSIT_PER_BYTE: Final[Uint] = Uint(200)

    # Utility
    ZERO: Final[Uint] = Uint(0)
    MEMORY_PER_WORD: Final[Uint] = Uint(3)
    FAST_STEP: Final[Uint] = Uint(5)

    # Refunds
    REFUND_STORAGE_CLEAR: Final[int] = 15000
    REFUND_SELF_DESTRUCT: Final[int] = 24000

    # Precompiles
    PRECOMPILE_ECRECOVER: Final[Uint] = Uint(3000)
    PRECOMPILE_SHA256_BASE: Final[Uint] = Uint(60)
    PRECOMPILE_SHA256_PER_WORD: Final[Uint] = Uint(12)
    PRECOMPILE_RIPEMD160_BASE: Final[Uint] = Uint(600)
    PRECOMPILE_RIPEMD160_PER_WORD: Final[Uint] = Uint(120)
    PRECOMPILE_IDENTITY_BASE: Final[Uint] = Uint(15)
    PRECOMPILE_IDENTITY_PER_WORD: Final[Uint] = Uint(3)
    PRECOMPILE_BLAKE2F_PER_ROUND: Final[Uint] = Uint(1)
    PRECOMPILE_ECADD: Final[Uint] = Uint(150)
    PRECOMPILE_ECMUL: Final[Uint] = Uint(6000)
    PRECOMPILE_ECPAIRING_BASE: Final[Uint] = Uint(45000)
    PRECOMPILE_ECPAIRING_PER_POINT: Final[Uint] = Uint(34000)

    # Transactions
    TX_BASE: Final[Uint] = Uint(21000)
    TX_CREATE: Final[Uint] = Uint(32000)
    TX_DATA_PER_ZERO: Final[Uint] = Uint(4)
    TX_DATA_PER_NON_ZERO: Final[Uint] = Uint(16)

    # Block
    LIMIT_ADJUSTMENT_FACTOR: Final[Uint] = Uint(1024)
    LIMIT_MINIMUM: Final[Uint] = Uint(5000)

    # Static Opcodes
    OPCODE_ADD: Final[Uint] = VERY_LOW
    OPCODE_SUB: Final[Uint] = VERY_LOW
    OPCODE_MUL: Final[Uint] = LOW
    OPCODE_DIV: Final[Uint] = LOW
    OPCODE_SDIV: Final[Uint] = LOW
    OPCODE_MOD: Final[Uint] = LOW
    OPCODE_SMOD: Final[Uint] = LOW
    OPCODE_ADDMOD: Final[Uint] = MID
    OPCODE_MULMOD: Final[Uint] = MID
    OPCODE_SIGNEXTEND: Final[Uint] = LOW
    OPCODE_LT: Final[Uint] = VERY_LOW
    OPCODE_GT: Final[Uint] = VERY_LOW
    OPCODE_SLT: Final[Uint] = VERY_LOW
    OPCODE_SGT: Final[Uint] = VERY_LOW
    OPCODE_EQ: Final[Uint] = VERY_LOW
    OPCODE_ISZERO: Final[Uint] = VERY_LOW
    OPCODE_AND: Final[Uint] = VERY_LOW
    OPCODE_OR: Final[Uint] = VERY_LOW
    OPCODE_XOR: Final[Uint] = VERY_LOW
    OPCODE_NOT: Final[Uint] = VERY_LOW
    OPCODE_BYTE: Final[Uint] = VERY_LOW
    OPCODE_SHL: Final[Uint] = VERY_LOW
    OPCODE_SHR: Final[Uint] = VERY_LOW
    OPCODE_SAR: Final[Uint] = VERY_LOW
    OPCODE_JUMP: Final[Uint] = MID
    OPCODE_JUMPI: Final[Uint] = HIGH
    OPCODE_JUMPDEST: Final[Uint] = Uint(1)
    OPCODE_CALLDATALOAD: Final[Uint] = VERY_LOW
    OPCODE_EXTCODEHASH: Final[Uint] = Uint(700)
    OPCODE_BLOCKHASH: Final[Uint] = Uint(20)
    OPCODE_COINBASE: Final[Uint] = BASE
    OPCODE_POP: Final[Uint] = BASE
    OPCODE_MSIZE: Final[Uint] = BASE
    OPCODE_PC: Final[Uint] = BASE
    OPCODE_GAS: Final[Uint] = BASE
    OPCODE_ADDRESS: Final[Uint] = BASE
    OPCODE_ORIGIN: Final[Uint] = BASE
    OPCODE_CALLER: Final[Uint] = BASE
    OPCODE_CALLVALUE: Final[Uint] = BASE
    OPCODE_CALLDATASIZE: Final[Uint] = BASE
    OPCODE_CODESIZE: Final[Uint] = BASE
    OPCODE_GASPRICE: Final[Uint] = BASE
    OPCODE_TIMESTAMP: Final[Uint] = BASE
    OPCODE_NUMBER: Final[Uint] = BASE
    OPCODE_GASLIMIT: Final[Uint] = BASE
    OPCODE_DIFFICULTY: Final[Uint] = BASE
    OPCODE_RETURNDATASIZE: Final[Uint] = BASE
    OPCODE_CHAINID: Final[Uint] = BASE
    OPCODE_PUSH: Final[Uint] = VERY_LOW
    OPCODE_DUP: Final[Uint] = VERY_LOW
    OPCODE_SWAP: Final[Uint] = VERY_LOW

    # Dynamic Opcodes
    OPCODE_RETURNDATACOPY_BASE: Final[Uint] = VERY_LOW
    OPCODE_RETURNDATACOPY_PER_WORD: Final[Uint] = Uint(3)
    OPCODE_CALLDATACOPY_BASE: Final[Uint] = VERY_LOW
    OPCODE_CODECOPY_BASE: Final[Uint] = VERY_LOW
    OPCODE_MLOAD_BASE: Final[Uint] = VERY_LOW
    OPCODE_MSTORE_BASE: Final[Uint] = VERY_LOW
    OPCODE_MSTORE8_BASE: Final[Uint] = VERY_LOW
    OPCODE_COPY_PER_WORD: Final[Uint] = Uint(3)
    OPCODE_CREATE_BASE: Final[Uint] = Uint(32000)
    OPCODE_EXP_BASE: Final[Uint] = Uint(10)
    OPCODE_EXP_PER_BYTE: Final[Uint] = Uint(50)
    OPCODE_KECCAK256_BASE: Final[Uint] = Uint(30)
    OPCODE_KECCAK256_PER_WORD: Final[Uint] = Uint(6)
    OPCODE_LOG_BASE: Final[Uint] = Uint(375)
    OPCODE_LOG_DATA_PER_BYTE: Final[Uint] = Uint(8)
    OPCODE_LOG_TOPIC: Final[Uint] = Uint(375)
    OPCODE_SELFDESTRUCT_BASE: Final[Uint] = Uint(5000)
    OPCODE_SELFDESTRUCT_NEW_ACCOUNT: Final[Uint] = Uint(25000)
    OPCODE_EXTERNAL_BASE: Final[Uint] = Uint(700)
    OPCODE_BALANCE: Final[Uint] = Uint(700)
    OPCODE_CALL_BASE: Final[Uint] = Uint(700)


@final
@dataclass
class ExtendMemory:
    """
    Define the parameters for memory extension in opcodes.

    `cost`: `ethereum.base_types.Uint`
        The gas required to perform the extension
    `expand_by`: `ethereum.base_types.Uint`
        The size by which the memory will be extended
    """

    cost: Uint
    expand_by: Uint


@final
@dataclass
class MessageCallGas:
    """
    Define the gas cost and gas given to the sub-call for executing the call
    opcodes.

    `cost`: `ethereum.base_types.Uint`
        The gas required to execute the call opcode, excludes
        memory expansion costs.
    `sub_call`: `ethereum.base_types.Uint`
        The portion of gas available to sub-calls that is refundable
        if not consumed.
    """

    cost: Uint
    sub_call: Uint


def charge_gas(evm: Evm, amount: Uint) -> None:
    """
    Subtracts `amount` from `evm.gas_left`.

    Parameters
    ----------
    evm :
        The current EVM.
    amount :
        The amount of gas the current operation requires.

    """
    evm_trace(evm, GasAndRefund(int(amount)))

    if evm.gas_left < amount:
        raise OutOfGasError
    else:
        evm.gas_left -= amount


def calculate_memory_gas_cost(size_in_bytes: Uint) -> Uint:
    """
    Calculates the gas cost for allocating memory
    to the smallest multiple of 32 bytes,
    such that the allocated size is at least as big as the given size.

    Parameters
    ----------
    size_in_bytes :
        The size of the data in bytes.

    Returns
    -------
    total_gas_cost : `ethereum.base_types.Uint`
        The gas cost for storing data in memory.

    """
    size_in_words = ceil32(size_in_bytes) // Uint(32)
    linear_cost = size_in_words * GasCosts.MEMORY_PER_WORD
    quadratic_cost = size_in_words ** Uint(2) // Uint(512)
    total_gas_cost = linear_cost + quadratic_cost
    try:
        return total_gas_cost
    except ValueError as e:
        raise OutOfGasError from e


def calculate_gas_extend_memory(
    memory: bytearray, extensions: List[Tuple[U256, U256]]
) -> ExtendMemory:
    """
    Calculates the gas amount to extend memory.

    Parameters
    ----------
    memory :
        Memory contents of the EVM.
    extensions:
        List of extensions to be made to the memory.
        Consists of a tuple of start position and size.

    Returns
    -------
    extend_memory: `ExtendMemory`

    """
    size_to_extend = Uint(0)
    to_be_paid = Uint(0)
    current_size = ulen(memory)
    for start_position, size in extensions:
        if size == 0:
            continue
        before_size = ceil32(current_size)
        after_size = ceil32(Uint(start_position) + Uint(size))
        if after_size <= before_size:
            continue

        size_to_extend += after_size - before_size
        already_paid = calculate_memory_gas_cost(before_size)
        total_cost = calculate_memory_gas_cost(after_size)
        to_be_paid += total_cost - already_paid

        current_size = after_size

    return ExtendMemory(to_be_paid, size_to_extend)


def calculate_message_call_gas(
    value: U256,
    gas: Uint,
    gas_left: Uint,
    memory_cost: Uint,
    extra_gas: Uint,
    call_stipend: Uint = GasCosts.CALL_STIPEND,
) -> MessageCallGas:
    """
    Calculates the MessageCallGas (cost and gas made available to the sub-call)
    for executing call Opcodes.

    Parameters
    ----------
    value:
        The amount of `ETH` that needs to be transferred.
    gas :
        The amount of gas provided to the message-call.
    gas_left :
        The amount of gas left in the current frame.
    memory_cost :
        The amount needed to extend the memory in the current frame.
    extra_gas :
        The amount of gas needed for transferring value + creating a new
        account inside a message call.
    call_stipend :
        The amount of stipend provided to a message call to execute code while
        transferring value (ETH).

    Returns
    -------
    message_call_gas: `MessageCallGas`

    """
    call_stipend = Uint(0) if value == 0 else call_stipend
    if gas_left < extra_gas + memory_cost:
        return MessageCallGas(gas + extra_gas, gas + call_stipend)

    gas = min(gas, max_message_call_gas(gas_left - memory_cost - extra_gas))

    return MessageCallGas(gas + extra_gas, gas + call_stipend)


def max_message_call_gas(gas: Uint) -> Uint:
    """
    Calculates the maximum gas that is allowed for making a message call.

    Parameters
    ----------
    gas :
        The amount of gas provided to the message-call.

    Returns
    -------
    max_allowed_message_call_gas: `ethereum.base_types.Uint`
        The maximum gas allowed for making the message-call.

    """
    return gas - (gas // Uint(64))

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/__init__.py
================================================================================

```python
"""
EVM Instruction Encoding (Opcodes).

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Machine readable representations of EVM instructions, and a mapping to their
implementations.
"""

import enum
from typing import Callable, Dict

from . import arithmetic as arithmetic_instructions
from . import bitwise as bitwise_instructions
from . import block as block_instructions
from . import comparison as comparison_instructions
from . import control_flow as control_flow_instructions
from . import environment as environment_instructions
from . import keccak as keccak_instructions
from . import log as log_instructions
from . import memory as memory_instructions
from . import stack as stack_instructions
from . import storage as storage_instructions
from . import system as system_instructions


class Ops(enum.Enum):
    """
    Enum for EVM Opcodes.
    """

    # Arithmetic Ops
    ADD = 0x01
    MUL = 0x02
    SUB = 0x03
    DIV = 0x04
    SDIV = 0x05
    MOD = 0x06
    SMOD = 0x07
    ADDMOD = 0x08
    MULMOD = 0x09
    EXP = 0x0A
    SIGNEXTEND = 0x0B

    # Comparison Ops
    LT = 0x10
    GT = 0x11
    SLT = 0x12
    SGT = 0x13
    EQ = 0x14
    ISZERO = 0x15

    # Bitwise Ops
    AND = 0x16
    OR = 0x17
    XOR = 0x18
    NOT = 0x19
    BYTE = 0x1A
    SHL = 0x1B
    SHR = 0x1C
    SAR = 0x1D

    # Keccak Op
    KECCAK = 0x20

    # Environmental Ops
    ADDRESS = 0x30
    BALANCE = 0x31
    ORIGIN = 0x32
    CALLER = 0x33
    CALLVALUE = 0x34
    CALLDATALOAD = 0x35
    CALLDATASIZE = 0x36
    CALLDATACOPY = 0x37
    CODESIZE = 0x38
    CODECOPY = 0x39
    GASPRICE = 0x3A
    EXTCODESIZE = 0x3B
    EXTCODECOPY = 0x3C
    RETURNDATASIZE = 0x3D
    RETURNDATACOPY = 0x3E
    EXTCODEHASH = 0x3F

    # Block Ops
    BLOCKHASH = 0x40
    COINBASE = 0x41
    TIMESTAMP = 0x42
    NUMBER = 0x43
    DIFFICULTY = 0x44
    GASLIMIT = 0x45
    CHAINID = 0x46
    SELFBALANCE = 0x47

    # Control Flow Ops
    STOP = 0x00
    JUMP = 0x56
    JUMPI = 0x57
    PC = 0x58
    GAS = 0x5A
    JUMPDEST = 0x5B

    # Storage Ops
    SLOAD = 0x54
    SSTORE = 0x55

    # Pop Operation
    POP = 0x50

    # Push Operations
    PUSH1 = 0x60
    PUSH2 = 0x61
    PUSH3 = 0x62
    PUSH4 = 0x63
    PUSH5 = 0x64
    PUSH6 = 0x65
    PUSH7 = 0x66
    PUSH8 = 0x67
    PUSH9 = 0x68
    PUSH10 = 0x69
    PUSH11 = 0x6A
    PUSH12 = 0x6B
    PUSH13 = 0x6C
    PUSH14 = 0x6D
    PUSH15 = 0x6E
    PUSH16 = 0x6F
    PUSH17 = 0x70
    PUSH18 = 0x71
    PUSH19 = 0x72
    PUSH20 = 0x73
    PUSH21 = 0x74
    PUSH22 = 0x75
    PUSH23 = 0x76
    PUSH24 = 0x77
    PUSH25 = 0x78
    PUSH26 = 0x79
    PUSH27 = 0x7A
    PUSH28 = 0x7B
    PUSH29 = 0x7C
    PUSH30 = 0x7D
    PUSH31 = 0x7E
    PUSH32 = 0x7F

    # Dup operations
    DUP1 = 0x80
    DUP2 = 0x81
    DUP3 = 0x82
    DUP4 = 0x83
    DUP5 = 0x84
    DUP6 = 0x85
    DUP7 = 0x86
    DUP8 = 0x87
    DUP9 = 0x88
    DUP10 = 0x89
    DUP11 = 0x8A
    DUP12 = 0x8B
    DUP13 = 0x8C
    DUP14 = 0x8D
    DUP15 = 0x8E
    DUP16 = 0x8F

    # Swap operations
    SWAP1 = 0x90
    SWAP2 = 0x91
    SWAP3 = 0x92
    SWAP4 = 0x93
    SWAP5 = 0x94
    SWAP6 = 0x95
    SWAP7 = 0x96
    SWAP8 = 0x97
    SWAP9 = 0x98
    SWAP10 = 0x99
    SWAP11 = 0x9A
    SWAP12 = 0x9B
    SWAP13 = 0x9C
    SWAP14 = 0x9D
    SWAP15 = 0x9E
    SWAP16 = 0x9F

    # Memory Operations
    MLOAD = 0x51
    MSTORE = 0x52
    MSTORE8 = 0x53
    MSIZE = 0x59

    # Log Operations
    LOG0 = 0xA0
    LOG1 = 0xA1
    LOG2 = 0xA2
    LOG3 = 0xA3
    LOG4 = 0xA4

    # System Operations
    CREATE = 0xF0
    CALL = 0xF1
    CALLCODE = 0xF2
    RETURN = 0xF3
    DELEGATECALL = 0xF4
    CREATE2 = 0xF5
    STATICCALL = 0xFA
    REVERT = 0xFD
    SELFDESTRUCT = 0xFF


op_implementation: Dict[Ops, Callable] = {
    Ops.STOP: control_flow_instructions.stop,
    Ops.ADD: arithmetic_instructions.add,
    Ops.MUL: arithmetic_instructions.mul,
    Ops.SUB: arithmetic_instructions.sub,
    Ops.DIV: arithmetic_instructions.div,
    Ops.SDIV: arithmetic_instructions.sdiv,
    Ops.MOD: arithmetic_instructions.mod,
    Ops.SMOD: arithmetic_instructions.smod,
    Ops.ADDMOD: arithmetic_instructions.addmod,
    Ops.MULMOD: arithmetic_instructions.mulmod,
    Ops.EXP: arithmetic_instructions.exp,
    Ops.SIGNEXTEND: arithmetic_instructions.signextend,
    Ops.LT: comparison_instructions.less_than,
    Ops.GT: comparison_instructions.greater_than,
    Ops.SLT: comparison_instructions.signed_less_than,
    Ops.SGT: comparison_instructions.signed_greater_than,
    Ops.EQ: comparison_instructions.equal,
    Ops.ISZERO: comparison_instructions.is_zero,
    Ops.AND: bitwise_instructions.bitwise_and,
    Ops.OR: bitwise_instructions.bitwise_or,
    Ops.XOR: bitwise_instructions.bitwise_xor,
    Ops.NOT: bitwise_instructions.bitwise_not,
    Ops.BYTE: bitwise_instructions.get_byte,
    Ops.SHL: bitwise_instructions.bitwise_shl,
    Ops.SHR: bitwise_instructions.bitwise_shr,
    Ops.SAR: bitwise_instructions.bitwise_sar,
    Ops.KECCAK: keccak_instructions.keccak,
    Ops.SLOAD: storage_instructions.sload,
    Ops.BLOCKHASH: block_instructions.block_hash,
    Ops.COINBASE: block_instructions.coinbase,
    Ops.TIMESTAMP: block_instructions.timestamp,
    Ops.NUMBER: block_instructions.number,
    Ops.DIFFICULTY: block_instructions.difficulty,
    Ops.GASLIMIT: block_instructions.gas_limit,
    Ops.CHAINID: block_instructions.chain_id,
    Ops.MLOAD: memory_instructions.mload,
    Ops.MSTORE: memory_instructions.mstore,
    Ops.MSTORE8: memory_instructions.mstore8,
    Ops.MSIZE: memory_instructions.msize,
    Ops.ADDRESS: environment_instructions.address,
    Ops.BALANCE: environment_instructions.balance,
    Ops.ORIGIN: environment_instructions.origin,
    Ops.CALLER: environment_instructions.caller,
    Ops.CALLVALUE: environment_instructions.callvalue,
    Ops.CALLDATALOAD: environment_instructions.calldataload,
    Ops.CALLDATASIZE: environment_instructions.calldatasize,
    Ops.CALLDATACOPY: environment_instructions.calldatacopy,
    Ops.CODESIZE: environment_instructions.codesize,
    Ops.CODECOPY: environment_instructions.codecopy,
    Ops.GASPRICE: environment_instructions.gasprice,
    Ops.EXTCODESIZE: environment_instructions.extcodesize,
    Ops.EXTCODECOPY: environment_instructions.extcodecopy,
    Ops.RETURNDATASIZE: environment_instructions.returndatasize,
    Ops.RETURNDATACOPY: environment_instructions.returndatacopy,
    Ops.EXTCODEHASH: environment_instructions.extcodehash,
    Ops.SELFBALANCE: environment_instructions.self_balance,
    Ops.SSTORE: storage_instructions.sstore,
    Ops.JUMP: control_flow_instructions.jump,
    Ops.JUMPI: control_flow_instructions.jumpi,
    Ops.PC: control_flow_instructions.pc,
    Ops.GAS: control_flow_instructions.gas_left,
    Ops.JUMPDEST: control_flow_instructions.jumpdest,
    Ops.POP: stack_instructions.pop,
    Ops.PUSH1: stack_instructions.push1,
    Ops.PUSH2: stack_instructions.push2,
    Ops.PUSH3: stack_instructions.push3,
    Ops.PUSH4: stack_instructions.push4,
    Ops.PUSH5: stack_instructions.push5,
    Ops.PUSH6: stack_instructions.push6,
    Ops.PUSH7: stack_instructions.push7,
    Ops.PUSH8: stack_instructions.push8,
    Ops.PUSH9: stack_instructions.push9,
    Ops.PUSH10: stack_instructions.push10,
    Ops.PUSH11: stack_instructions.push11,
    Ops.PUSH12: stack_instructions.push12,
    Ops.PUSH13: stack_instructions.push13,
    Ops.PUSH14: stack_instructions.push14,
    Ops.PUSH15: stack_instructions.push15,
    Ops.PUSH16: stack_instructions.push16,
    Ops.PUSH17: stack_instructions.push17,
    Ops.PUSH18: stack_instructions.push18,
    Ops.PUSH19: stack_instructions.push19,
    Ops.PUSH20: stack_instructions.push20,
    Ops.PUSH21: stack_instructions.push21,
    Ops.PUSH22: stack_instructions.push22,
    Ops.PUSH23: stack_instructions.push23,
    Ops.PUSH24: stack_instructions.push24,
    Ops.PUSH25: stack_instructions.push25,
    Ops.PUSH26: stack_instructions.push26,
    Ops.PUSH27: stack_instructions.push27,
    Ops.PUSH28: stack_instructions.push28,
    Ops.PUSH29: stack_instructions.push29,
    Ops.PUSH30: stack_instructions.push30,
    Ops.PUSH31: stack_instructions.push31,
    Ops.PUSH32: stack_instructions.push32,
    Ops.DUP1: stack_instructions.dup1,
    Ops.DUP2: stack_instructions.dup2,
    Ops.DUP3: stack_instructions.dup3,
    Ops.DUP4: stack_instructions.dup4,
    Ops.DUP5: stack_instructions.dup5,
    Ops.DUP6: stack_instructions.dup6,
    Ops.DUP7: stack_instructions.dup7,
    Ops.DUP8: stack_instructions.dup8,
    Ops.DUP9: stack_instructions.dup9,
    Ops.DUP10: stack_instructions.dup10,
    Ops.DUP11: stack_instructions.dup11,
    Ops.DUP12: stack_instructions.dup12,
    Ops.DUP13: stack_instructions.dup13,
    Ops.DUP14: stack_instructions.dup14,
    Ops.DUP15: stack_instructions.dup15,
    Ops.DUP16: stack_instructions.dup16,
    Ops.SWAP1: stack_instructions.swap1,
    Ops.SWAP2: stack_instructions.swap2,
    Ops.SWAP3: stack_instructions.swap3,
    Ops.SWAP4: stack_instructions.swap4,
    Ops.SWAP5: stack_instructions.swap5,
    Ops.SWAP6: stack_instructions.swap6,
    Ops.SWAP7: stack_instructions.swap7,
    Ops.SWAP8: stack_instructions.swap8,
    Ops.SWAP9: stack_instructions.swap9,
    Ops.SWAP10: stack_instructions.swap10,
    Ops.SWAP11: stack_instructions.swap11,
    Ops.SWAP12: stack_instructions.swap12,
    Ops.SWAP13: stack_instructions.swap13,
    Ops.SWAP14: stack_instructions.swap14,
    Ops.SWAP15: stack_instructions.swap15,
    Ops.SWAP16: stack_instructions.swap16,
    Ops.LOG0: log_instructions.log0,
    Ops.LOG1: log_instructions.log1,
    Ops.LOG2: log_instructions.log2,
    Ops.LOG3: log_instructions.log3,
    Ops.LOG4: log_instructions.log4,
    Ops.CREATE: system_instructions.create,
    Ops.RETURN: system_instructions.return_,
    Ops.CALL: system_instructions.call,
    Ops.CALLCODE: system_instructions.callcode,
    Ops.DELEGATECALL: system_instructions.delegatecall,
    Ops.SELFDESTRUCT: system_instructions.selfdestruct,
    Ops.STATICCALL: system_instructions.staticcall,
    Ops.REVERT: system_instructions.revert,
    Ops.CREATE2: system_instructions.create2,
}

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/arithmetic.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Arithmetic Instructions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementations of the EVM Arithmetic instructions.
"""

from ethereum_types.bytes import Bytes
from ethereum_types.numeric import U256, Uint

from ethereum.utils.numeric import get_sign

from .. import Evm
from ..gas import (
    GasCosts,
    charge_gas,
)
from ..stack import pop, push


def add(evm: Evm) -> None:
    """
    Adds the top two elements of the stack together, and pushes the result back
    on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    x = pop(evm.stack)
    y = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_ADD)

    # OPERATION
    result = x.wrapping_add(y)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def sub(evm: Evm) -> None:
    """
    Subtracts the top two elements of the stack, and pushes the result back
    on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    x = pop(evm.stack)
    y = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_SUB)

    # OPERATION
    result = x.wrapping_sub(y)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def mul(evm: Evm) -> None:
    """
    Multiplies the top two elements of the stack, and pushes the result back
    on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    x = pop(evm.stack)
    y = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_MUL)

    # OPERATION
    result = x.wrapping_mul(y)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def div(evm: Evm) -> None:
    """
    Integer division of the top two elements of the stack. Pushes the result
    back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    dividend = pop(evm.stack)
    divisor = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_DIV)

    # OPERATION
    if divisor == 0:
        quotient = U256(0)
    else:
        quotient = dividend // divisor

    push(evm.stack, quotient)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


U255_CEIL_VALUE = 2**255


def sdiv(evm: Evm) -> None:
    """
    Signed integer division of the top two elements of the stack. Pushes the
    result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    dividend = pop(evm.stack).to_signed()
    divisor = pop(evm.stack).to_signed()

    # GAS
    charge_gas(evm, GasCosts.OPCODE_SDIV)

    # OPERATION
    if divisor == 0:
        quotient = 0
    elif dividend == -U255_CEIL_VALUE and divisor == -1:
        quotient = -U255_CEIL_VALUE
    else:
        sign = get_sign(dividend * divisor)
        quotient = sign * (abs(dividend) // abs(divisor))

    push(evm.stack, U256.from_signed(quotient))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def mod(evm: Evm) -> None:
    """
    Modulo remainder of the top two elements of the stack. Pushes the result
    back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    x = pop(evm.stack)
    y = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_MOD)

    # OPERATION
    if y == 0:
        remainder = U256(0)
    else:
        remainder = x % y

    push(evm.stack, remainder)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def smod(evm: Evm) -> None:
    """
    Signed modulo remainder of the top two elements of the stack. Pushes the
    result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    x = pop(evm.stack).to_signed()
    y = pop(evm.stack).to_signed()

    # GAS
    charge_gas(evm, GasCosts.OPCODE_SMOD)

    # OPERATION
    if y == 0:
        remainder = 0
    else:
        remainder = get_sign(x) * (abs(x) % abs(y))

    push(evm.stack, U256.from_signed(remainder))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def addmod(evm: Evm) -> None:
    """
    Modulo addition of the top 2 elements with the 3rd element. Pushes the
    result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    x = Uint(pop(evm.stack))
    y = Uint(pop(evm.stack))
    z = Uint(pop(evm.stack))

    # GAS
    charge_gas(evm, GasCosts.OPCODE_ADDMOD)

    # OPERATION
    if z == 0:
        result = U256(0)
    else:
        result = U256((x + y) % z)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def mulmod(evm: Evm) -> None:
    """
    Modulo multiplication of the top 2 elements with the 3rd element. Pushes
    the result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    x = Uint(pop(evm.stack))
    y = Uint(pop(evm.stack))
    z = Uint(pop(evm.stack))

    # GAS
    charge_gas(evm, GasCosts.OPCODE_MULMOD)

    # OPERATION
    if z == 0:
        result = U256(0)
    else:
        result = U256((x * y) % z)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def exp(evm: Evm) -> None:
    """
    Exponential operation of the top 2 elements. Pushes the result back on
    the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    base = Uint(pop(evm.stack))
    exponent = Uint(pop(evm.stack))

    # GAS
    # This is equivalent to 1 + floor(log(y, 256)). But in python the log
    # function is inaccurate leading to wrong results.
    exponent_bits = exponent.bit_length()
    exponent_bytes = (exponent_bits + Uint(7)) // Uint(8)
    charge_gas(
        evm,
        GasCosts.OPCODE_EXP_BASE
        + GasCosts.OPCODE_EXP_PER_BYTE * exponent_bytes,
    )

    # OPERATION
    result = U256(pow(base, exponent, Uint(U256.MAX_VALUE) + Uint(1)))

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def signextend(evm: Evm) -> None:
    """
    Sign extend operation. In other words, extend a signed number which
    fits in N bytes to 32 bytes.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    byte_num = pop(evm.stack)
    value = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_SIGNEXTEND)

    # OPERATION
    if byte_num > U256(31):
        # Can't extend any further
        result = value
    else:
        # U256(0).to_be_bytes() gives b'' instead of b'\x00'.
        value_bytes = Bytes(value.to_be_bytes32())
        # Now among the obtained value bytes, consider only
        # N `least significant bytes`, where N is `byte_num + 1`.
        value_bytes = value_bytes[31 - int(byte_num) :]
        sign_bit = value_bytes[0] >> 7
        if sign_bit == 0:
            result = U256.from_be_bytes(value_bytes)
        else:
            num_bytes_prepend = U256(32) - (byte_num + U256(1))
            result = U256.from_be_bytes(
                bytearray([0xFF] * num_bytes_prepend) + value_bytes
            )

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/bitwise.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Bitwise Instructions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementations of the EVM bitwise instructions.
"""

from ethereum_types.numeric import U256, Uint

from .. import Evm
from ..gas import (
    GasCosts,
    charge_gas,
)
from ..stack import pop, push


def bitwise_and(evm: Evm) -> None:
    """
    Bitwise AND operation of the top 2 elements of the stack. Pushes the
    result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    x = pop(evm.stack)
    y = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_AND)

    # OPERATION
    push(evm.stack, x & y)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def bitwise_or(evm: Evm) -> None:
    """
    Bitwise OR operation of the top 2 elements of the stack. Pushes the
    result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    x = pop(evm.stack)
    y = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_OR)

    # OPERATION
    push(evm.stack, x | y)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def bitwise_xor(evm: Evm) -> None:
    """
    Bitwise XOR operation of the top 2 elements of the stack. Pushes the
    result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    x = pop(evm.stack)
    y = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_XOR)

    # OPERATION
    push(evm.stack, x ^ y)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def bitwise_not(evm: Evm) -> None:
    """
    Bitwise NOT operation of the top element of the stack. Pushes the
    result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    x = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_NOT)

    # OPERATION
    push(evm.stack, ~x)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def get_byte(evm: Evm) -> None:
    """
    For a word (defined by next top element of the stack), retrieve the
    Nth byte (0-indexed and defined by top element of stack) from the
    left (most significant) to right (least significant).

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    byte_index = pop(evm.stack)
    word = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_BYTE)

    # OPERATION
    if byte_index >= U256(32):
        result = U256(0)
    else:
        extra_bytes_to_right = U256(31) - byte_index
        # Remove the extra bytes in the right
        word = word >> (extra_bytes_to_right * U256(8))
        # Remove the extra bytes in the left
        word = word & U256(0xFF)
        result = word

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def bitwise_shl(evm: Evm) -> None:
    """
    Logical shift left (SHL) operation of the top 2 elements of the stack.
    Pushes the result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    shift = Uint(pop(evm.stack))
    value = Uint(pop(evm.stack))

    # GAS
    charge_gas(evm, GasCosts.OPCODE_SHL)

    # OPERATION
    if shift < Uint(256):
        result = U256((value << shift) & Uint(U256.MAX_VALUE))
    else:
        result = U256(0)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def bitwise_shr(evm: Evm) -> None:
    """
    Logical shift right (SHR) operation of the top 2 elements of the stack.
    Pushes the result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    shift = pop(evm.stack)
    value = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_SHR)

    # OPERATION
    if shift < U256(256):
        result = value >> shift
    else:
        result = U256(0)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def bitwise_sar(evm: Evm) -> None:
    """
    Arithmetic shift right (SAR) operation of the top 2 elements of the stack.
    Pushes the result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    shift = int(pop(evm.stack))
    signed_value = pop(evm.stack).to_signed()

    # GAS
    charge_gas(evm, GasCosts.OPCODE_SAR)

    # OPERATION
    if shift < 256:
        result = U256.from_signed(signed_value >> shift)
    elif signed_value >= 0:
        result = U256(0)
    else:
        result = U256.MAX_VALUE

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/block.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Block Instructions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementations of the EVM block instructions.
"""

from ethereum_types.numeric import U256, Uint

from .. import Evm
from ..gas import GasCosts, charge_gas
from ..stack import pop, push


def block_hash(evm: Evm) -> None:
    """
    Push the hash of one of the 256 most recent complete blocks onto the
    stack. The block number to hash is present at the top of the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    block_number = Uint(pop(evm.stack))

    # GAS
    charge_gas(evm, GasCosts.OPCODE_BLOCKHASH)

    # OPERATION
    max_block_number = block_number + Uint(256)
    current_block_number = evm.message.block_env.number
    if (
        current_block_number <= block_number
        or current_block_number > max_block_number
    ):
        # Default hash to 0, if the block of interest is not yet on the chain
        # (including the block which has the current executing transaction),
        # or if the block's age is more than 256.
        current_block_hash = b"\x00"
    else:
        current_block_hash = evm.message.block_env.block_hashes[
            -(current_block_number - block_number)
        ]

    push(evm.stack, U256.from_be_bytes(current_block_hash))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def coinbase(evm: Evm) -> None:
    """
    Push the current block's beneficiary address (address of the block miner)
    onto the stack.

    Here the current block refers to the block in which the currently
    executing transaction/call resides.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_COINBASE)

    # OPERATION
    push(evm.stack, U256.from_be_bytes(evm.message.block_env.coinbase))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def timestamp(evm: Evm) -> None:
    """
    Push the current block's timestamp onto the stack. Here the timestamp
    being referred to is actually the unix timestamp in seconds.

    Here the current block refers to the block in which the currently
    executing transaction/call resides.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_TIMESTAMP)

    # OPERATION
    push(evm.stack, evm.message.block_env.time)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def number(evm: Evm) -> None:
    """
    Push the current block's number onto the stack.

    Here the current block refers to the block in which the currently
    executing transaction/call resides.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_NUMBER)

    # OPERATION
    push(evm.stack, U256(evm.message.block_env.number))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def difficulty(evm: Evm) -> None:
    """
    Push the current block's difficulty onto the stack.

    Here the current block refers to the block in which the currently
    executing transaction/call resides.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_DIFFICULTY)

    # OPERATION
    push(evm.stack, U256(evm.message.block_env.difficulty))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def gas_limit(evm: Evm) -> None:
    """
    Push the current block's gas limit onto the stack.

    Here the current block refers to the block in which the currently
    executing transaction/call resides.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_GASLIMIT)

    # OPERATION
    push(evm.stack, U256(evm.message.block_env.block_gas_limit))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def chain_id(evm: Evm) -> None:
    """
    Push the chain id onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_CHAINID)

    # OPERATION
    push(evm.stack, U256(evm.message.block_env.chain_id))

    # PROGRAM COUNTER
    evm.pc += Uint(1)

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/comparison.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Comparison Instructions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementations of the EVM Comparison instructions.
"""

from ethereum_types.numeric import U256, Uint

from .. import Evm
from ..gas import (
    GasCosts,
    charge_gas,
)
from ..stack import pop, push


def less_than(evm: Evm) -> None:
    """
    Checks if the top element is less than the next top element. Pushes the
    result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    left = pop(evm.stack)
    right = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_LT)

    # OPERATION
    result = U256(left < right)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def signed_less_than(evm: Evm) -> None:
    """
    Signed less-than comparison.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    left = pop(evm.stack).to_signed()
    right = pop(evm.stack).to_signed()

    # GAS
    charge_gas(evm, GasCosts.OPCODE_SLT)

    # OPERATION
    result = U256(left < right)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def greater_than(evm: Evm) -> None:
    """
    Checks if the top element is greater than the next top element. Pushes
    the result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    left = pop(evm.stack)
    right = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_GT)

    # OPERATION
    result = U256(left > right)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def signed_greater_than(evm: Evm) -> None:
    """
    Signed greater-than comparison.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    left = pop(evm.stack).to_signed()
    right = pop(evm.stack).to_signed()

    # GAS
    charge_gas(evm, GasCosts.OPCODE_SGT)

    # OPERATION
    result = U256(left > right)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def equal(evm: Evm) -> None:
    """
    Checks if the top element is equal to the next top element. Pushes
    the result back on the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    left = pop(evm.stack)
    right = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_EQ)

    # OPERATION
    result = U256(left == right)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def is_zero(evm: Evm) -> None:
    """
    Checks if the top element is equal to 0. Pushes the result back on the
    stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    x = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_ISZERO)

    # OPERATION
    result = U256(x == 0)

    push(evm.stack, result)

    # PROGRAM COUNTER
    evm.pc += Uint(1)

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/control_flow.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Control Flow Instructions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementations of the EVM control flow instructions.
"""

from ethereum_types.numeric import U256, Uint

from ...vm.gas import (
    GasCosts,
    charge_gas,
)
from .. import Evm
from ..exceptions import InvalidJumpDestError
from ..stack import pop, push


def stop(evm: Evm) -> None:
    """
    Stop further execution of EVM code.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    pass

    # OPERATION
    evm.running = False

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def jump(evm: Evm) -> None:
    """
    Alter the program counter to the location specified by the top of the
    stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    jump_dest = Uint(pop(evm.stack))

    # GAS
    charge_gas(evm, GasCosts.OPCODE_JUMP)

    # OPERATION
    if jump_dest not in evm.valid_jump_destinations:
        raise InvalidJumpDestError

    # PROGRAM COUNTER
    evm.pc = Uint(jump_dest)


def jumpi(evm: Evm) -> None:
    """
    Alter the program counter to the specified location if and only if a
    condition is true. If the condition is not true, then the program counter
    would increase only by 1.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    jump_dest = Uint(pop(evm.stack))
    conditional_value = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_JUMPI)

    # OPERATION
    if conditional_value == 0:
        destination = evm.pc + Uint(1)
    elif jump_dest not in evm.valid_jump_destinations:
        raise InvalidJumpDestError
    else:
        destination = jump_dest

    # PROGRAM COUNTER
    evm.pc = destination


def pc(evm: Evm) -> None:
    """
    Push onto the stack the value of the program counter after reaching the
    current instruction and without increasing it for the next instruction.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_PC)

    # OPERATION
    push(evm.stack, U256(evm.pc))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def gas_left(evm: Evm) -> None:
    """
    Push the amount of available gas (including the corresponding reduction
    for the cost of this instruction) onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_GAS)

    # OPERATION
    push(evm.stack, U256(evm.gas_left))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def jumpdest(evm: Evm) -> None:
    """
    Mark a valid destination for jumps. This is a noop, present only
    to be used by `JUMP` and `JUMPI` opcodes to verify that their jump is
    valid.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_JUMPDEST)

    # OPERATION
    pass

    # PROGRAM COUNTER
    evm.pc += Uint(1)

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/environment.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Environmental Instructions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementations of the EVM environment related instructions.
"""

from ethereum_types.numeric import U256, Uint, ulen

from ethereum.state import EMPTY_ACCOUNT
from ethereum.utils.numeric import ceil32

from ...state_tracker import get_account, get_code
from ...utils.address import to_address_masked
from ...vm.memory import buffer_read, memory_write
from .. import Evm
from ..exceptions import OutOfBoundsRead
from ..gas import (
    GasCosts,
    calculate_gas_extend_memory,
    charge_gas,
)
from ..stack import pop, push


def address(evm: Evm) -> None:
    """
    Pushes the address of the current executing account to the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_ADDRESS)

    # OPERATION
    push(evm.stack, U256.from_be_bytes(evm.message.current_target))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def balance(evm: Evm) -> None:
    """
    Pushes the balance of the given account onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    address = to_address_masked(pop(evm.stack))

    # GAS
    charge_gas(evm, GasCosts.OPCODE_BALANCE)

    # OPERATION
    # Non-existent accounts default to EMPTY_ACCOUNT, which has balance 0.
    tx_state = evm.message.tx_env.state
    balance = get_account(tx_state, address).balance

    push(evm.stack, balance)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def origin(evm: Evm) -> None:
    """
    Pushes the address of the original transaction sender to the stack.
    The origin address can only be an EOA.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_ORIGIN)

    # OPERATION
    push(evm.stack, U256.from_be_bytes(evm.message.tx_env.origin))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def caller(evm: Evm) -> None:
    """
    Pushes the address of the caller onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_CALLER)

    # OPERATION
    push(evm.stack, U256.from_be_bytes(evm.message.caller))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def callvalue(evm: Evm) -> None:
    """
    Push the value (in wei) sent with the call onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_CALLVALUE)

    # OPERATION
    push(evm.stack, evm.message.value)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def calldataload(evm: Evm) -> None:
    """
    Push a word (32 bytes) of the input data belonging to the current
    environment onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    start_index = pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_CALLDATALOAD)

    # OPERATION
    value = buffer_read(evm.message.data, start_index, U256(32))

    push(evm.stack, U256.from_be_bytes(value))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def calldatasize(evm: Evm) -> None:
    """
    Push the size of input data in current environment onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_CALLDATASIZE)

    # OPERATION
    push(evm.stack, U256(len(evm.message.data)))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def calldatacopy(evm: Evm) -> None:
    """
    Copy a portion of the input data in current environment to memory.

    This will also expand the memory, in case that the memory is insufficient
    to store the data.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    memory_start_index = pop(evm.stack)
    data_start_index = pop(evm.stack)
    size = pop(evm.stack)

    # GAS
    words = ceil32(Uint(size)) // Uint(32)
    copy_gas_cost = GasCosts.OPCODE_COPY_PER_WORD * words
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(memory_start_index, size)]
    )
    charge_gas(
        evm,
        GasCosts.OPCODE_CALLDATACOPY_BASE + copy_gas_cost + extend_memory.cost,
    )

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    value = buffer_read(evm.message.data, data_start_index, size)
    memory_write(evm.memory, memory_start_index, value)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def codesize(evm: Evm) -> None:
    """
    Push the size of code running in current environment onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_CODESIZE)

    # OPERATION
    push(evm.stack, U256(len(evm.code)))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def codecopy(evm: Evm) -> None:
    """
    Copy a portion of the code in current environment to memory.

    This will also expand the memory, in case that the memory is insufficient
    to store the data.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    memory_start_index = pop(evm.stack)
    code_start_index = pop(evm.stack)
    size = pop(evm.stack)

    # GAS
    words = ceil32(Uint(size)) // Uint(32)
    copy_gas_cost = GasCosts.OPCODE_COPY_PER_WORD * words
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(memory_start_index, size)]
    )
    charge_gas(
        evm,
        GasCosts.OPCODE_CODECOPY_BASE + copy_gas_cost + extend_memory.cost,
    )

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    value = buffer_read(evm.code, code_start_index, size)
    memory_write(evm.memory, memory_start_index, value)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def gasprice(evm: Evm) -> None:
    """
    Push the gas price used in current environment onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_GASPRICE)

    # OPERATION
    push(evm.stack, U256(evm.message.tx_env.gas_price))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def extcodesize(evm: Evm) -> None:
    """
    Push the code size of a given account onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    address = to_address_masked(pop(evm.stack))

    # GAS
    charge_gas(evm, GasCosts.OPCODE_EXTERNAL_BASE)

    # OPERATION
    tx_state = evm.message.tx_env.state
    account = get_account(tx_state, address)
    code = get_code(tx_state, account.code_hash)

    codesize = U256(len(code))
    push(evm.stack, codesize)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def extcodecopy(evm: Evm) -> None:
    """
    Copy a portion of an account's code to memory.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    address = to_address_masked(pop(evm.stack))
    memory_start_index = pop(evm.stack)
    code_start_index = pop(evm.stack)
    size = pop(evm.stack)

    # GAS
    words = ceil32(Uint(size)) // Uint(32)
    copy_gas_cost = GasCosts.OPCODE_COPY_PER_WORD * words
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(memory_start_index, size)]
    )
    charge_gas(
        evm,
        GasCosts.OPCODE_EXTERNAL_BASE + copy_gas_cost + extend_memory.cost,
    )

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    tx_state = evm.message.tx_env.state
    account = get_account(tx_state, address)
    code = get_code(tx_state, account.code_hash)

    value = buffer_read(code, code_start_index, size)
    memory_write(evm.memory, memory_start_index, value)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def returndatasize(evm: Evm) -> None:
    """
    Pushes the size of the return data buffer onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_RETURNDATASIZE)

    # OPERATION
    push(evm.stack, U256(len(evm.return_data)))

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def returndatacopy(evm: Evm) -> None:
    """
    Copies data from the return data buffer to memory.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    memory_start_index = pop(evm.stack)
    return_data_start_position = pop(evm.stack)
    size = pop(evm.stack)

    # GAS
    words = ceil32(Uint(size)) // Uint(32)
    copy_gas_cost = GasCosts.OPCODE_RETURNDATACOPY_PER_WORD * words
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(memory_start_index, size)]
    )
    charge_gas(
        evm,
        GasCosts.OPCODE_RETURNDATACOPY_BASE
        + copy_gas_cost
        + extend_memory.cost,
    )
    if Uint(return_data_start_position) + Uint(size) > ulen(evm.return_data):
        raise OutOfBoundsRead

    evm.memory += b"\x00" * extend_memory.expand_by
    value = evm.return_data[
        return_data_start_position : return_data_start_position + size
    ]
    memory_write(evm.memory, memory_start_index, value)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def extcodehash(evm: Evm) -> None:
    """
    Returns the keccak256 hash of a contract’s bytecode.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    address = to_address_masked(pop(evm.stack))

    # GAS
    charge_gas(evm, GasCosts.OPCODE_EXTCODEHASH)

    # OPERATION
    account = get_account(evm.message.tx_env.state, address)

    if account == EMPTY_ACCOUNT:
        codehash = U256(0)
    else:
        codehash = U256.from_be_bytes(account.code_hash)

    push(evm.stack, codehash)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def self_balance(evm: Evm) -> None:
    """
    Pushes the balance of the current address to the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.FAST_STEP)

    # OPERATION
    # Non-existent accounts default to EMPTY_ACCOUNT, which has balance 0.
    balance = get_account(
        evm.message.tx_env.state, evm.message.current_target
    ).balance

    push(evm.stack, balance)

    # PROGRAM COUNTER
    evm.pc += Uint(1)

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/keccak.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Keccak Instructions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementations of the EVM keccak instructions.
"""

from ethereum_types.numeric import U256, Uint

from ethereum.crypto.hash import keccak256
from ethereum.utils.numeric import ceil32

from .. import Evm
from ..gas import (
    GasCosts,
    calculate_gas_extend_memory,
    charge_gas,
)
from ..memory import memory_read_bytes
from ..stack import pop, push


def keccak(evm: Evm) -> None:
    """
    Pushes to the stack the Keccak-256 hash of a region of memory.

    This also expands the memory, in case the memory is insufficient to
    access the data's memory location.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    memory_start_index = pop(evm.stack)
    size = pop(evm.stack)

    # GAS
    words = ceil32(Uint(size)) // Uint(32)
    word_gas_cost = GasCosts.OPCODE_KECCAK256_PER_WORD * words
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(memory_start_index, size)]
    )
    charge_gas(
        evm,
        GasCosts.OPCODE_KECCAK256_BASE + word_gas_cost + extend_memory.cost,
    )

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    data = memory_read_bytes(evm.memory, memory_start_index, size)
    hashed = keccak256(data)

    push(evm.stack, U256.from_be_bytes(hashed))

    # PROGRAM COUNTER
    evm.pc += Uint(1)

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/log.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Logging Instructions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementations of the EVM logging instructions.
"""

from functools import partial
from typing import Callable

from ethereum_types.numeric import Uint

from ...blocks import Log
from .. import Evm
from ..exceptions import WriteInStaticContext
from ..gas import (
    GasCosts,
    calculate_gas_extend_memory,
    charge_gas,
)
from ..memory import memory_read_bytes
from ..stack import pop


def log_n(evm: Evm, num_topics: int) -> None:
    """
    Appends a log entry, having `num_topics` topics, to the evm logs.

    This will also expand the memory if the data (required by the log entry)
    corresponding to the memory is not accessible.

    Parameters
    ----------
    evm :
        The current EVM frame.
    num_topics :
        The number of topics to be included in the log entry.

    """
    # STACK
    memory_start_index = pop(evm.stack)
    size = pop(evm.stack)

    topics = []
    for _ in range(num_topics):
        topic = pop(evm.stack).to_be_bytes32()
        topics.append(topic)

    # GAS
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(memory_start_index, size)]
    )
    charge_gas(
        evm,
        GasCosts.OPCODE_LOG_BASE
        + GasCosts.OPCODE_LOG_DATA_PER_BYTE * Uint(size)
        + GasCosts.OPCODE_LOG_TOPIC * Uint(num_topics)
        + extend_memory.cost,
    )

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    if evm.message.is_static:
        raise WriteInStaticContext
    log_entry = Log(
        address=evm.message.current_target,
        topics=tuple(topics),
        data=memory_read_bytes(evm.memory, memory_start_index, size),
    )

    evm.logs = evm.logs + (log_entry,)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


log0: Callable[[Evm], None] = partial(log_n, num_topics=0)
log1: Callable[[Evm], None] = partial(log_n, num_topics=1)
log2: Callable[[Evm], None] = partial(log_n, num_topics=2)
log3: Callable[[Evm], None] = partial(log_n, num_topics=3)
log4: Callable[[Evm], None] = partial(log_n, num_topics=4)

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/memory.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Memory Instructions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementations of the EVM Memory instructions.
"""

from ethereum_types.bytes import Bytes
from ethereum_types.numeric import U256, Uint

from .. import Evm
from ..gas import (
    GasCosts,
    calculate_gas_extend_memory,
    charge_gas,
)
from ..memory import memory_read_bytes, memory_write
from ..stack import pop, push


def mstore(evm: Evm) -> None:
    """
    Stores a word to memory.
    This also expands the memory, if the memory is
    insufficient to store the word.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    start_position = pop(evm.stack)
    value = pop(evm.stack).to_be_bytes32()

    # GAS
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(start_position, U256(len(value)))]
    )

    charge_gas(evm, GasCosts.OPCODE_MSTORE_BASE + extend_memory.cost)

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    memory_write(evm.memory, start_position, value)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def mstore8(evm: Evm) -> None:
    """
    Stores a byte to memory.
    This also expands the memory, if the memory is
    insufficient to store the word.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    start_position = pop(evm.stack)
    value = pop(evm.stack)

    # GAS
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(start_position, U256(1))]
    )

    charge_gas(evm, GasCosts.OPCODE_MSTORE8_BASE + extend_memory.cost)

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    normalized_bytes_value = Bytes([value & U256(0xFF)])
    memory_write(evm.memory, start_position, normalized_bytes_value)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def mload(evm: Evm) -> None:
    """
    Loads a word from memory.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    start_position = pop(evm.stack)

    # GAS
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(start_position, U256(32))]
    )
    charge_gas(evm, GasCosts.OPCODE_MLOAD_BASE + extend_memory.cost)

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    value = U256.from_be_bytes(
        memory_read_bytes(evm.memory, start_position, U256(32))
    )
    push(evm.stack, value)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def msize(evm: Evm) -> None:
    """
    Pushes the size of active memory in bytes onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_MSIZE)

    # OPERATION
    push(evm.stack, U256(len(evm.memory)))

    # PROGRAM COUNTER
    evm.pc += Uint(1)

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/stack.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Stack Instructions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementations of the EVM stack related instructions.
"""

from functools import partial
from typing import Callable

from ethereum_types.numeric import U256, Uint

from .. import Evm, stack
from ..exceptions import StackUnderflowError
from ..gas import (
    GasCosts,
    charge_gas,
)
from ..memory import buffer_read


def pop(evm: Evm) -> None:
    """
    Removes an item from the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    stack.pop(evm.stack)

    # GAS
    charge_gas(evm, GasCosts.OPCODE_POP)

    # OPERATION
    pass

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def push_n(evm: Evm, num_bytes: int) -> None:
    """
    Pushes an N-byte immediate onto the stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    num_bytes :
        The number of immediate bytes to be read from the code and pushed to
        the stack.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_PUSH)

    # OPERATION
    data_to_push = U256.from_be_bytes(
        buffer_read(evm.code, U256(evm.pc + Uint(1)), U256(num_bytes))
    )
    stack.push(evm.stack, data_to_push)

    # PROGRAM COUNTER
    evm.pc += Uint(1) + Uint(num_bytes)


def dup_n(evm: Evm, item_number: int) -> None:
    """
    Duplicates the Nth stack item (from top of the stack) to the top of stack.

    Parameters
    ----------
    evm :
        The current EVM frame.

    item_number :
        The stack item number (0-indexed from top of stack) to be duplicated
        to the top of stack.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_DUP)
    if item_number >= len(evm.stack):
        raise StackUnderflowError
    data_to_duplicate = evm.stack[len(evm.stack) - 1 - item_number]
    stack.push(evm.stack, data_to_duplicate)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def swap_n(evm: Evm, item_number: int) -> None:
    """
    Swaps the top and the `item_number` element of the stack, where
    the top of the stack is position zero.

    If `item_number` is zero, this function does nothing (which should not be
    possible, since there is no `SWAP0` instruction).

    Parameters
    ----------
    evm :
        The current EVM frame.

    item_number :
        The stack item number (0-indexed from top of stack) to be swapped
        with the top of stack element.

    """
    # STACK
    pass

    # GAS
    charge_gas(evm, GasCosts.OPCODE_SWAP)
    if item_number >= len(evm.stack):
        raise StackUnderflowError
    evm.stack[-1], evm.stack[-1 - item_number] = (
        evm.stack[-1 - item_number],
        evm.stack[-1],
    )

    # PROGRAM COUNTER
    evm.pc += Uint(1)


push1: Callable[[Evm], None] = partial(push_n, num_bytes=1)
push2: Callable[[Evm], None] = partial(push_n, num_bytes=2)
push3: Callable[[Evm], None] = partial(push_n, num_bytes=3)
push4: Callable[[Evm], None] = partial(push_n, num_bytes=4)
push5: Callable[[Evm], None] = partial(push_n, num_bytes=5)
push6: Callable[[Evm], None] = partial(push_n, num_bytes=6)
push7: Callable[[Evm], None] = partial(push_n, num_bytes=7)
push8: Callable[[Evm], None] = partial(push_n, num_bytes=8)
push9: Callable[[Evm], None] = partial(push_n, num_bytes=9)
push10: Callable[[Evm], None] = partial(push_n, num_bytes=10)
push11: Callable[[Evm], None] = partial(push_n, num_bytes=11)
push12: Callable[[Evm], None] = partial(push_n, num_bytes=12)
push13: Callable[[Evm], None] = partial(push_n, num_bytes=13)
push14: Callable[[Evm], None] = partial(push_n, num_bytes=14)
push15: Callable[[Evm], None] = partial(push_n, num_bytes=15)
push16: Callable[[Evm], None] = partial(push_n, num_bytes=16)
push17: Callable[[Evm], None] = partial(push_n, num_bytes=17)
push18: Callable[[Evm], None] = partial(push_n, num_bytes=18)
push19: Callable[[Evm], None] = partial(push_n, num_bytes=19)
push20: Callable[[Evm], None] = partial(push_n, num_bytes=20)
push21: Callable[[Evm], None] = partial(push_n, num_bytes=21)
push22: Callable[[Evm], None] = partial(push_n, num_bytes=22)
push23: Callable[[Evm], None] = partial(push_n, num_bytes=23)
push24: Callable[[Evm], None] = partial(push_n, num_bytes=24)
push25: Callable[[Evm], None] = partial(push_n, num_bytes=25)
push26: Callable[[Evm], None] = partial(push_n, num_bytes=26)
push27: Callable[[Evm], None] = partial(push_n, num_bytes=27)
push28: Callable[[Evm], None] = partial(push_n, num_bytes=28)
push29: Callable[[Evm], None] = partial(push_n, num_bytes=29)
push30: Callable[[Evm], None] = partial(push_n, num_bytes=30)
push31: Callable[[Evm], None] = partial(push_n, num_bytes=31)
push32: Callable[[Evm], None] = partial(push_n, num_bytes=32)

dup1: Callable[[Evm], None] = partial(dup_n, item_number=0)
dup2: Callable[[Evm], None] = partial(dup_n, item_number=1)
dup3: Callable[[Evm], None] = partial(dup_n, item_number=2)
dup4: Callable[[Evm], None] = partial(dup_n, item_number=3)
dup5: Callable[[Evm], None] = partial(dup_n, item_number=4)
dup6: Callable[[Evm], None] = partial(dup_n, item_number=5)
dup7: Callable[[Evm], None] = partial(dup_n, item_number=6)
dup8: Callable[[Evm], None] = partial(dup_n, item_number=7)
dup9: Callable[[Evm], None] = partial(dup_n, item_number=8)
dup10: Callable[[Evm], None] = partial(dup_n, item_number=9)
dup11: Callable[[Evm], None] = partial(dup_n, item_number=10)
dup12: Callable[[Evm], None] = partial(dup_n, item_number=11)
dup13: Callable[[Evm], None] = partial(dup_n, item_number=12)
dup14: Callable[[Evm], None] = partial(dup_n, item_number=13)
dup15: Callable[[Evm], None] = partial(dup_n, item_number=14)
dup16: Callable[[Evm], None] = partial(dup_n, item_number=15)

swap1: Callable[[Evm], None] = partial(swap_n, item_number=1)
swap2: Callable[[Evm], None] = partial(swap_n, item_number=2)
swap3: Callable[[Evm], None] = partial(swap_n, item_number=3)
swap4: Callable[[Evm], None] = partial(swap_n, item_number=4)
swap5: Callable[[Evm], None] = partial(swap_n, item_number=5)
swap6: Callable[[Evm], None] = partial(swap_n, item_number=6)
swap7: Callable[[Evm], None] = partial(swap_n, item_number=7)
swap8: Callable[[Evm], None] = partial(swap_n, item_number=8)
swap9: Callable[[Evm], None] = partial(swap_n, item_number=9)
swap10: Callable[[Evm], None] = partial(swap_n, item_number=10)
swap11: Callable[[Evm], None] = partial(swap_n, item_number=11)
swap12: Callable[[Evm], None] = partial(swap_n, item_number=12)
swap13: Callable[[Evm], None] = partial(swap_n, item_number=13)
swap14: Callable[[Evm], None] = partial(swap_n, item_number=14)
swap15: Callable[[Evm], None] = partial(swap_n, item_number=15)
swap16: Callable[[Evm], None] = partial(swap_n, item_number=16)

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/storage.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Storage Instructions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementations of the EVM storage related instructions.
"""

from ethereum_types.numeric import Uint

from ...state_tracker import get_storage, get_storage_original, set_storage
from .. import Evm
from ..exceptions import OutOfGasError, WriteInStaticContext
from ..gas import (
    GasCosts,
    charge_gas,
)
from ..stack import pop, push


def sload(evm: Evm) -> None:
    """
    Loads to the stack, the value corresponding to a certain key from the
    storage of the current account.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    key = pop(evm.stack).to_be_bytes32()

    # GAS
    charge_gas(evm, GasCosts.SLOAD)

    # OPERATION
    tx_state = evm.message.tx_env.state
    value = get_storage(tx_state, evm.message.current_target, key)

    push(evm.stack, value)

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def sstore(evm: Evm) -> None:
    """
    Stores a value at a certain key in the current context's storage.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    key = pop(evm.stack).to_be_bytes32()
    new_value = pop(evm.stack)
    if evm.gas_left <= GasCosts.CALL_STIPEND:
        raise OutOfGasError

    tx_state = evm.message.tx_env.state
    original_value = get_storage_original(
        tx_state, evm.message.current_target, key
    )
    current_value = get_storage(tx_state, evm.message.current_target, key)

    if original_value == current_value and current_value != new_value:
        if original_value == 0:
            gas_cost = GasCosts.STORAGE_SET
        else:
            gas_cost = GasCosts.COLD_STORAGE_WRITE
    else:
        gas_cost = GasCosts.SLOAD

    # Refund Counter Calculation
    if current_value != new_value:
        if original_value != 0 and current_value != 0 and new_value == 0:
            # Storage is cleared for the first time in the transaction
            evm.refund_counter += GasCosts.REFUND_STORAGE_CLEAR

        if original_value != 0 and current_value == 0:
            # Gas refund issued earlier to be reversed
            evm.refund_counter -= GasCosts.REFUND_STORAGE_CLEAR

        if original_value == new_value:
            # Storage slot being restored to its original value
            if original_value == 0:
                # Slot was originally empty and was SET earlier
                evm.refund_counter += int(
                    GasCosts.STORAGE_SET - GasCosts.SLOAD
                )
            else:
                # Slot was originally non-empty and was UPDATED earlier
                evm.refund_counter += int(
                    GasCosts.COLD_STORAGE_WRITE - GasCosts.SLOAD
                )

    charge_gas(evm, gas_cost)
    if evm.message.is_static:
        raise WriteInStaticContext
    set_storage(tx_state, evm.message.current_target, key, new_value)

    # PROGRAM COUNTER
    evm.pc += Uint(1)

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/instructions/system.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) System Instructions.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementations of the EVM system related instructions.
"""

from dataclasses import dataclass
from typing import final

from ethereum_types.bytes import Bytes, Bytes0
from ethereum_types.numeric import U256, Uint

from ethereum.state import Address
from ethereum.utils.numeric import ceil32

from ...state_tracker import (
    account_deployable,
    account_exists_and_is_empty,
    get_account,
    get_code,
    increment_nonce,
    is_account_alive,
    set_account_balance,
)
from ...utils.address import (
    compute_contract_address,
    compute_create2_contract_address,
    to_address_masked,
)
from .. import (
    Evm,
    Message,
    incorporate_child_on_error,
    incorporate_child_on_success,
)
from ..exceptions import Revert, WriteInStaticContext
from ..gas import (
    GasCosts,
    calculate_gas_extend_memory,
    calculate_message_call_gas,
    charge_gas,
    max_message_call_gas,
)
from ..memory import memory_read_bytes, memory_write
from ..stack import pop, push


def generic_create(
    evm: Evm,
    endowment: U256,
    contract_address: Address,
    memory_start_position: U256,
    memory_size: U256,
) -> None:
    """
    Core logic used by the `CREATE*` family of opcodes.
    """
    # This import causes a circular import error
    # if it's not moved inside this method
    from ...vm.interpreter import STACK_DEPTH_LIMIT, process_create_message

    call_data = memory_read_bytes(
        evm.memory, memory_start_position, memory_size
    )

    create_message_gas = max_message_call_gas(Uint(evm.gas_left))
    evm.gas_left -= create_message_gas
    if evm.message.is_static:
        raise WriteInStaticContext
    evm.return_data = b""

    sender_address = evm.message.current_target
    sender = get_account(evm.message.tx_env.state, sender_address)

    if (
        sender.balance < endowment
        or sender.nonce == Uint(2**64 - 1)
        or evm.message.depth + Uint(1) > STACK_DEPTH_LIMIT
    ):
        evm.gas_left += create_message_gas
        push(evm.stack, U256(0))
        return

    if not account_deployable(evm.message.tx_env.state, contract_address):
        increment_nonce(evm.message.tx_env.state, evm.message.current_target)
        push(evm.stack, U256(0))
        return

    call_data = memory_read_bytes(
        evm.memory, memory_start_position, memory_size
    )

    increment_nonce(evm.message.tx_env.state, evm.message.current_target)

    child_message = Message(
        block_env=evm.message.block_env,
        tx_env=evm.message.tx_env,
        caller=evm.message.current_target,
        target=Bytes0(),
        gas=create_message_gas,
        value=endowment,
        data=b"",
        code=call_data,
        current_target=contract_address,
        depth=evm.message.depth + Uint(1),
        code_address=None,
        should_transfer_value=True,
        is_static=False,
        parent_evm=evm,
    )
    child_evm = process_create_message(child_message)

    if child_evm.error:
        incorporate_child_on_error(evm, child_evm)
        evm.return_data = child_evm.output
        push(evm.stack, U256(0))
    else:
        incorporate_child_on_success(evm, child_evm)
        evm.return_data = b""
        push(evm.stack, U256.from_be_bytes(child_evm.message.current_target))


def create(evm: Evm) -> None:
    """
    Creates a new account with associated code.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    endowment = pop(evm.stack)
    memory_start_position = pop(evm.stack)
    memory_size = pop(evm.stack)

    # GAS
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(memory_start_position, memory_size)]
    )

    charge_gas(evm, GasCosts.OPCODE_CREATE_BASE + extend_memory.cost)

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    contract_address = compute_contract_address(
        evm.message.current_target,
        get_account(
            evm.message.tx_env.state, evm.message.current_target
        ).nonce,
    )

    generic_create(
        evm, endowment, contract_address, memory_start_position, memory_size
    )

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def create2(evm: Evm) -> None:
    """
    Creates a new account with associated code.

    It's similar to the CREATE opcode except that the address of the new
    account depends on the init_code instead of the nonce of sender.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    endowment = pop(evm.stack)
    memory_start_position = pop(evm.stack)
    memory_size = pop(evm.stack)
    salt = pop(evm.stack).to_be_bytes32()

    # GAS
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(memory_start_position, memory_size)]
    )
    call_data_words = ceil32(Uint(memory_size)) // Uint(32)
    charge_gas(
        evm,
        GasCosts.OPCODE_CREATE_BASE
        + GasCosts.OPCODE_KECCAK256_PER_WORD * call_data_words
        + extend_memory.cost,
    )

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    contract_address = compute_create2_contract_address(
        evm.message.current_target,
        salt,
        memory_read_bytes(evm.memory, memory_start_position, memory_size),
    )

    generic_create(
        evm, endowment, contract_address, memory_start_position, memory_size
    )

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def return_(evm: Evm) -> None:
    """
    Halts execution returning output data.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    memory_start_position = pop(evm.stack)
    memory_size = pop(evm.stack)

    # GAS
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(memory_start_position, memory_size)]
    )

    charge_gas(evm, GasCosts.ZERO + extend_memory.cost)

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    evm.output = memory_read_bytes(
        evm.memory, memory_start_position, memory_size
    )

    evm.running = False

    # PROGRAM COUNTER
    pass


@final
@dataclass
class GenericCall:
    """
    Parameters for the core logic of the `CALL*` family of opcodes.
    """

    gas: Uint
    value: U256
    caller: Address
    to: Address
    code_address: Address
    should_transfer_value: bool
    is_staticcall: bool
    memory_input_start_position: U256
    memory_input_size: U256
    memory_output_start_position: U256
    memory_output_size: U256


def generic_call(evm: Evm, params: GenericCall) -> None:
    """
    Perform the core logic of the `CALL*` family of opcodes.
    """
    from ...vm.interpreter import STACK_DEPTH_LIMIT, process_message

    evm.return_data = b""

    if evm.message.depth + Uint(1) > STACK_DEPTH_LIMIT:
        evm.gas_left += params.gas
        push(evm.stack, U256(0))
        return

    call_data = memory_read_bytes(
        evm.memory,
        params.memory_input_start_position,
        params.memory_input_size,
    )
    code_account = get_account(evm.message.tx_env.state, params.code_address)
    code = get_code(evm.message.tx_env.state, code_account.code_hash)
    child_message = Message(
        block_env=evm.message.block_env,
        tx_env=evm.message.tx_env,
        caller=params.caller,
        target=params.to,
        gas=params.gas,
        value=params.value,
        data=call_data,
        code=code,
        current_target=params.to,
        depth=evm.message.depth + Uint(1),
        code_address=params.code_address,
        should_transfer_value=params.should_transfer_value,
        is_static=params.is_staticcall or evm.message.is_static,
        parent_evm=evm,
    )
    child_evm = process_message(child_message)

    if child_evm.error:
        incorporate_child_on_error(evm, child_evm)
        evm.return_data = child_evm.output
        push(evm.stack, U256(0))
    else:
        incorporate_child_on_success(evm, child_evm)
        evm.return_data = child_evm.output
        push(evm.stack, U256(1))

    actual_output_size = min(
        params.memory_output_size, U256(len(child_evm.output))
    )
    memory_write(
        evm.memory,
        params.memory_output_start_position,
        child_evm.output[:actual_output_size],
    )


def call(evm: Evm) -> None:
    """
    Message-call into an account.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    gas = Uint(pop(evm.stack))
    to = to_address_masked(pop(evm.stack))
    value = pop(evm.stack)
    memory_input_start_position = pop(evm.stack)
    memory_input_size = pop(evm.stack)
    memory_output_start_position = pop(evm.stack)
    memory_output_size = pop(evm.stack)

    # GAS
    extend_memory = calculate_gas_extend_memory(
        evm.memory,
        [
            (memory_input_start_position, memory_input_size),
            (memory_output_start_position, memory_output_size),
        ],
    )

    code_address = to

    create_gas_cost = GasCosts.NEW_ACCOUNT
    if value == 0 or is_account_alive(evm.message.tx_env.state, to):
        create_gas_cost = Uint(0)
    transfer_gas_cost = Uint(0) if value == 0 else GasCosts.CALL_VALUE
    message_call_gas = calculate_message_call_gas(
        value,
        gas,
        Uint(evm.gas_left),
        memory_cost=extend_memory.cost,
        extra_gas=GasCosts.OPCODE_CALL_BASE
        + create_gas_cost
        + transfer_gas_cost,
    )
    charge_gas(evm, message_call_gas.cost + extend_memory.cost)
    if evm.message.is_static and value != U256(0):
        raise WriteInStaticContext
    evm.memory += b"\x00" * extend_memory.expand_by
    sender_balance = get_account(
        evm.message.tx_env.state, evm.message.current_target
    ).balance
    if sender_balance < value:
        push(evm.stack, U256(0))
        evm.return_data = b""
        evm.gas_left += message_call_gas.sub_call
    else:
        generic_call(
            evm,
            GenericCall(
                gas=message_call_gas.sub_call,
                value=value,
                caller=evm.message.current_target,
                to=to,
                code_address=code_address,
                should_transfer_value=True,
                is_staticcall=False,
                memory_input_start_position=memory_input_start_position,
                memory_input_size=memory_input_size,
                memory_output_start_position=memory_output_start_position,
                memory_output_size=memory_output_size,
            ),
        )

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def callcode(evm: Evm) -> None:
    """
    Message-call into this account with alternative account’s code.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    gas = Uint(pop(evm.stack))
    code_address = to_address_masked(pop(evm.stack))
    value = pop(evm.stack)
    memory_input_start_position = pop(evm.stack)
    memory_input_size = pop(evm.stack)
    memory_output_start_position = pop(evm.stack)
    memory_output_size = pop(evm.stack)

    # GAS
    to = evm.message.current_target

    extend_memory = calculate_gas_extend_memory(
        evm.memory,
        [
            (memory_input_start_position, memory_input_size),
            (memory_output_start_position, memory_output_size),
        ],
    )
    transfer_gas_cost = Uint(0) if value == 0 else GasCosts.CALL_VALUE
    message_call_gas = calculate_message_call_gas(
        value,
        gas,
        Uint(evm.gas_left),
        extend_memory.cost,
        GasCosts.OPCODE_CALL_BASE + transfer_gas_cost,
    )
    charge_gas(evm, message_call_gas.cost + extend_memory.cost)

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    sender_balance = get_account(
        evm.message.tx_env.state, evm.message.current_target
    ).balance
    if sender_balance < value:
        push(evm.stack, U256(0))
        evm.return_data = b""
        evm.gas_left += message_call_gas.sub_call
    else:
        generic_call(
            evm,
            GenericCall(
                gas=message_call_gas.sub_call,
                value=value,
                caller=evm.message.current_target,
                to=to,
                code_address=code_address,
                should_transfer_value=True,
                is_staticcall=False,
                memory_input_start_position=memory_input_start_position,
                memory_input_size=memory_input_size,
                memory_output_start_position=memory_output_start_position,
                memory_output_size=memory_output_size,
            ),
        )

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def selfdestruct(evm: Evm) -> None:
    """
    Halt execution and register account for later deletion.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    beneficiary = to_address_masked(pop(evm.stack))

    # GAS
    gas_cost = GasCosts.OPCODE_SELFDESTRUCT_BASE
    if (
        not is_account_alive(evm.message.tx_env.state, beneficiary)
        and get_account(
            evm.message.tx_env.state, evm.message.current_target
        ).balance
        != 0
    ):
        gas_cost += GasCosts.OPCODE_SELFDESTRUCT_NEW_ACCOUNT

    originator = evm.message.current_target

    refunded_accounts = evm.accounts_to_delete
    parent_evm = evm.message.parent_evm
    while parent_evm is not None:
        refunded_accounts.update(parent_evm.accounts_to_delete)
        parent_evm = parent_evm.message.parent_evm

    if originator not in refunded_accounts:
        evm.refund_counter += GasCosts.REFUND_SELF_DESTRUCT

    charge_gas(evm, gas_cost)
    if evm.message.is_static:
        raise WriteInStaticContext

    originator = evm.message.current_target
    beneficiary_balance = get_account(
        evm.message.tx_env.state, beneficiary
    ).balance
    originator_balance = get_account(
        evm.message.tx_env.state, originator
    ).balance

    # First Transfer to beneficiary
    set_account_balance(
        evm.message.tx_env.state,
        beneficiary,
        beneficiary_balance + originator_balance,
    )
    # Next, Zero the balance of the address being deleted (must come after
    # sending to beneficiary in case the contract named itself as the
    # beneficiary).
    set_account_balance(evm.message.tx_env.state, originator, U256(0))

    # register account for deletion
    evm.accounts_to_delete.add(originator)

    # mark beneficiary as touched
    if account_exists_and_is_empty(evm.message.tx_env.state, beneficiary):
        evm.touched_accounts.add(beneficiary)

    # HALT the execution
    evm.running = False

    # PROGRAM COUNTER
    pass


def delegatecall(evm: Evm) -> None:
    """
    Message-call into an account.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    gas = Uint(pop(evm.stack))
    code_address = to_address_masked(pop(evm.stack))
    memory_input_start_position = pop(evm.stack)
    memory_input_size = pop(evm.stack)
    memory_output_start_position = pop(evm.stack)
    memory_output_size = pop(evm.stack)

    # GAS
    extend_memory = calculate_gas_extend_memory(
        evm.memory,
        [
            (memory_input_start_position, memory_input_size),
            (memory_output_start_position, memory_output_size),
        ],
    )
    message_call_gas = calculate_message_call_gas(
        U256(0),
        gas,
        Uint(evm.gas_left),
        extend_memory.cost,
        GasCosts.OPCODE_CALL_BASE,
    )
    charge_gas(evm, message_call_gas.cost + extend_memory.cost)

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    generic_call(
        evm,
        GenericCall(
            gas=message_call_gas.sub_call,
            value=evm.message.value,
            caller=evm.message.caller,
            to=evm.message.current_target,
            code_address=code_address,
            should_transfer_value=False,
            is_staticcall=False,
            memory_input_start_position=memory_input_start_position,
            memory_input_size=memory_input_size,
            memory_output_start_position=memory_output_start_position,
            memory_output_size=memory_output_size,
        ),
    )

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def staticcall(evm: Evm) -> None:
    """
    Message-call into an account.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    gas = Uint(pop(evm.stack))
    to = to_address_masked(pop(evm.stack))
    memory_input_start_position = pop(evm.stack)
    memory_input_size = pop(evm.stack)
    memory_output_start_position = pop(evm.stack)
    memory_output_size = pop(evm.stack)

    # GAS
    extend_memory = calculate_gas_extend_memory(
        evm.memory,
        [
            (memory_input_start_position, memory_input_size),
            (memory_output_start_position, memory_output_size),
        ],
    )

    code_address = to

    message_call_gas = calculate_message_call_gas(
        U256(0),
        gas,
        Uint(evm.gas_left),
        extend_memory.cost,
        GasCosts.OPCODE_CALL_BASE,
    )
    charge_gas(evm, message_call_gas.cost + extend_memory.cost)

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    generic_call(
        evm,
        GenericCall(
            gas=message_call_gas.sub_call,
            value=U256(0),
            caller=evm.message.current_target,
            to=to,
            code_address=code_address,
            should_transfer_value=True,
            is_staticcall=True,
            memory_input_start_position=memory_input_start_position,
            memory_input_size=memory_input_size,
            memory_output_start_position=memory_output_start_position,
            memory_output_size=memory_output_size,
        ),
    )

    # PROGRAM COUNTER
    evm.pc += Uint(1)


def revert(evm: Evm) -> None:
    """
    Stop execution and revert state changes, without consuming all provided gas
    and also has the ability to return a reason.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    # STACK
    memory_start_index = pop(evm.stack)
    size = pop(evm.stack)

    # GAS
    extend_memory = calculate_gas_extend_memory(
        evm.memory, [(memory_start_index, size)]
    )

    charge_gas(evm, extend_memory.cost)

    # OPERATION
    evm.memory += b"\x00" * extend_memory.expand_by
    output = memory_read_bytes(evm.memory, memory_start_index, size)
    evm.output = Bytes(output)
    raise Revert

    # PROGRAM COUNTER
    # no-op

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/interpreter.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Interpreter.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

A straightforward interpreter that executes EVM code.
"""

from dataclasses import dataclass
from typing import Optional, Set, Tuple, final

from ethereum_types.bytes import Bytes0
from ethereum_types.numeric import U256, Uint, ulen

from ethereum.exceptions import EthereumException
from ethereum.state import Address
from ethereum.trace import (
    EvmStop,
    OpEnd,
    OpException,
    OpStart,
    PrecompileEnd,
    PrecompileStart,
    TransactionEnd,
    evm_trace,
)

from ..blocks import Log
from ..state_tracker import (
    account_deployable,
    account_exists_and_is_empty,
    copy_tx_state,
    destroy_storage,
    increment_nonce,
    mark_account_created,
    move_ether,
    restore_tx_state,
    set_code,
    touch_account,
)
from ..vm import Message
from ..vm.gas import GasCosts, charge_gas
from ..vm.precompiled_contracts.mapping import PRE_COMPILED_CONTRACTS
from . import Evm
from .exceptions import (
    AddressCollision,
    ExceptionalHalt,
    InvalidOpcode,
    OutOfGasError,
    Revert,
    StackDepthLimitError,
)
from .instructions import Ops, op_implementation
from .runtime import get_valid_jump_destinations

STACK_DEPTH_LIMIT = Uint(1024)
MAX_CODE_SIZE = 0x6000


@final
@dataclass
class MessageCallOutput:
    """
    Output of a particular message call.

    Contains the following:

          1. `gas_left`: remaining gas after execution.
          2. `refund_counter`: gas to refund after execution.
          3. `logs`: list of `Log` generated during execution.
          4. `accounts_to_delete`: Contracts which have self-destructed.
          5. `touched_accounts`: Accounts that have been touched.
          6. `error`: The error from the execution if any.
    """

    gas_left: Uint
    refund_counter: U256
    logs: Tuple[Log, ...]
    accounts_to_delete: Set[Address]
    touched_accounts: Set[Address]
    error: Optional[EthereumException]


def process_message_call(message: Message) -> MessageCallOutput:
    """
    If `message.target` is empty then it creates a smart contract
    else it executes a call from the `message.caller` to the `message.target`.

    Parameters
    ----------
    message :
        Transaction specific items.

    Returns
    -------
    output : `MessageCallOutput`
        Output of the message call

    """
    tx_state = message.tx_env.state
    refund_counter = U256(0)
    if message.target == Bytes0(b""):
        if account_deployable(tx_state, message.current_target):
            evm = process_create_message(message)
        else:
            return MessageCallOutput(
                gas_left=Uint(0),
                refund_counter=U256(0),
                logs=tuple(),
                accounts_to_delete=set(),
                touched_accounts=set(),
                error=AddressCollision(),
            )
    else:
        evm = process_message(message)
        if account_exists_and_is_empty(tx_state, Address(message.target)):
            evm.touched_accounts.add(Address(message.target))

    if evm.error:
        logs: Tuple[Log, ...] = ()
        accounts_to_delete = set()
        touched_accounts = set()
    else:
        logs = evm.logs
        accounts_to_delete = evm.accounts_to_delete
        touched_accounts = evm.touched_accounts
        refund_counter += U256(evm.refund_counter)

    tx_end = TransactionEnd(
        int(message.gas) - int(evm.gas_left), evm.output, evm.error
    )
    evm_trace(evm, tx_end)

    return MessageCallOutput(
        gas_left=evm.gas_left,
        refund_counter=refund_counter,
        logs=logs,
        accounts_to_delete=accounts_to_delete,
        touched_accounts=touched_accounts,
        error=evm.error,
    )


def process_create_message(message: Message) -> Evm:
    """
    Executes a call to create a smart contract.

    Parameters
    ----------
    message :
        Transaction specific items.

    Returns
    -------
    evm: :py:class:`~ethereum.forks.muir_glacier.vm.Evm`
        Items containing execution specific objects.

    """
    tx_state = message.tx_env.state
    # take snapshot of state before processing the message
    snapshot = copy_tx_state(tx_state)

    # If the address where the account is being created has storage, it is
    # destroyed. This can only happen in the following highly unlikely
    # circumstances:
    # * The address created by a `CREATE` call collides with a subsequent
    #   `CREATE` or `CREATE2` call.
    # * The first `CREATE` happened before Spurious Dragon and left empty
    #   code.
    destroy_storage(tx_state, message.current_target)

    # In the previously mentioned edge case the preexisting storage is ignored
    # for gas refund purposes. In order to do this we must track created
    # accounts.
    mark_account_created(tx_state, message.current_target)

    increment_nonce(tx_state, message.current_target)
    evm = process_message(message)
    if not evm.error:
        contract_code = evm.output
        contract_code_gas = (
            ulen(contract_code) * GasCosts.CODE_DEPOSIT_PER_BYTE
        )
        try:
            charge_gas(evm, contract_code_gas)
            if len(contract_code) > MAX_CODE_SIZE:
                raise OutOfGasError
        except ExceptionalHalt as error:
            restore_tx_state(tx_state, snapshot)
            evm.gas_left = Uint(0)
            evm.output = b""
            evm.error = error
        else:
            set_code(tx_state, message.current_target, contract_code)
    else:
        restore_tx_state(tx_state, snapshot)
    return evm


def process_message(message: Message) -> Evm:
    """
    Move ether and execute the relevant code.

    Parameters
    ----------
    message :
        Transaction specific items.

    Returns
    -------
    evm: :py:class:`~ethereum.forks.muir_glacier.vm.Evm`
        Items containing execution specific objects

    """
    tx_state = message.tx_env.state
    if message.depth > STACK_DEPTH_LIMIT:
        raise StackDepthLimitError("Stack depth limit reached")

    code = message.code
    valid_jump_destinations = get_valid_jump_destinations(code)
    evm = Evm(
        pc=Uint(0),
        stack=[],
        memory=bytearray(),
        code=code,
        gas_left=message.gas,
        valid_jump_destinations=valid_jump_destinations,
        logs=(),
        refund_counter=0,
        running=True,
        message=message,
        output=b"",
        accounts_to_delete=set(),
        touched_accounts=set(),
        return_data=b"",
        error=None,
    )

    # take snapshot of state before processing the message
    snapshot = copy_tx_state(tx_state)

    touch_account(tx_state, message.current_target)

    if message.should_transfer_value and message.value != 0:
        move_ether(
            tx_state,
            message.caller,
            message.current_target,
            message.value,
        )

    try:
        if evm.message.code_address in PRE_COMPILED_CONTRACTS:
            evm_trace(evm, PrecompileStart(evm.message.code_address))
            PRE_COMPILED_CONTRACTS[evm.message.code_address](evm)
            evm_trace(evm, PrecompileEnd())
        else:
            while evm.running and evm.pc < ulen(evm.code):
                try:
                    op = Ops(evm.code[evm.pc])
                except ValueError as e:
                    raise InvalidOpcode(evm.code[evm.pc]) from e

                evm_trace(evm, OpStart(op))
                op_implementation[op](evm)
                evm_trace(evm, OpEnd())

            evm_trace(evm, EvmStop(Ops.STOP))

    except ExceptionalHalt as error:
        evm_trace(evm, OpException(error))
        evm.gas_left = Uint(0)
        evm.output = b""
        evm.error = error
    except Revert as error:
        evm_trace(evm, OpException(error))
        evm.error = error

    if evm.error:
        restore_tx_state(tx_state, snapshot)
    return evm

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/memory.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Memory.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

EVM memory operations.
"""

from ethereum_types.bytes import Bytes
from ethereum_types.numeric import U256, Uint

from ethereum.utils.byte import right_pad_zero_bytes


def memory_write(
    memory: bytearray, start_position: U256, value: Bytes
) -> None:
    """
    Writes to memory.

    Parameters
    ----------
    memory :
        Memory contents of the EVM.
    start_position :
        Starting pointer to the memory.
    value :
        Data to write to memory.

    """
    memory[start_position : int(start_position) + len(value)] = value


def memory_read_bytes(
    memory: bytearray, start_position: U256, size: U256
) -> Bytes:
    """
    Read bytes from memory.

    Parameters
    ----------
    memory :
        Memory contents of the EVM.
    start_position :
        Starting pointer to the memory.
    size :
        Size of the data that needs to be read from `start_position`.

    Returns
    -------
    data_bytes :
        Data read from memory.

    """
    return Bytes(memory[start_position : Uint(start_position) + Uint(size)])


def buffer_read(buffer: Bytes, start_position: U256, size: U256) -> Bytes:
    """
    Read bytes from a buffer. Padding with zeros if necessary.

    Parameters
    ----------
    buffer :
        Memory contents of the EVM.
    start_position :
        Starting pointer to the memory.
    size :
        Size of the data that needs to be read from `start_position`.

    Returns
    -------
    data_bytes :
        Data read from memory.

    """
    return right_pad_zero_bytes(
        buffer[start_position : Uint(start_position) + Uint(size)], size
    )

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/precompiled_contracts/__init__.py
================================================================================

```python
"""
Precompiled Contract Addresses.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Addresses of precompiled contracts and mappings to their
implementations.
"""

from ...utils.hexadecimal import hex_to_address

__all__ = (
    "ECRECOVER_ADDRESS",
    "SHA256_ADDRESS",
    "RIPEMD160_ADDRESS",
    "IDENTITY_ADDRESS",
    "MODEXP_ADDRESS",
    "ALT_BN128_ADD_ADDRESS",
    "ALT_BN128_MUL_ADDRESS",
    "ALT_BN128_PAIRING_CHECK_ADDRESS",
    "BLAKE2F_ADDRESS",
)

ECRECOVER_ADDRESS = hex_to_address("0x01")
SHA256_ADDRESS = hex_to_address("0x02")
RIPEMD160_ADDRESS = hex_to_address("0x03")
IDENTITY_ADDRESS = hex_to_address("0x04")
MODEXP_ADDRESS = hex_to_address("0x05")
ALT_BN128_ADD_ADDRESS = hex_to_address("0x06")
ALT_BN128_MUL_ADDRESS = hex_to_address("0x07")
ALT_BN128_PAIRING_CHECK_ADDRESS = hex_to_address("0x08")
BLAKE2F_ADDRESS = hex_to_address("0x09")

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/precompiled_contracts/alt_bn128.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) ALT_BN128 CONTRACTS.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementation of the ALT_BN128 precompiled contracts.
"""

from ethereum_types.bytes import Bytes
from ethereum_types.numeric import U256, Uint, ulen
from py_ecc.optimized_bn128.optimized_curve import (
    FQ,
    FQ2,
    FQ12,
    add,
    b,
    b2,
    curve_order,
    field_modulus,
    is_inf,
    is_on_curve,
    multiply,
    normalize,
)
from py_ecc.optimized_bn128.optimized_pairing import pairing
from py_ecc.typing import Optimized_Point3D as Point3D

from ...vm import Evm
from ...vm.gas import GasCosts, charge_gas
from ...vm.memory import buffer_read
from ..exceptions import InvalidParameter, OutOfGasError


def bytes_to_g1(data: Bytes) -> Point3D[FQ]:
    """
    Decode 64 bytes to a point on the curve.

    Parameters
    ----------
    data :
        The bytes data to decode.

    Returns
    -------
    point : Point3D
        A point on the curve.

    Raises
    ------
    InvalidParameter
        Either a field element is invalid or the point is not on the curve.

    """
    if len(data) != 64:
        raise InvalidParameter("Input should be 64 bytes long")

    x_bytes = buffer_read(data, U256(0), U256(32))
    x = int(U256.from_be_bytes(x_bytes))
    y_bytes = buffer_read(data, U256(32), U256(32))
    y = int(U256.from_be_bytes(y_bytes))

    if x >= field_modulus:
        raise InvalidParameter("Invalid field element")
    if y >= field_modulus:
        raise InvalidParameter("Invalid field element")

    z = 1
    if x == 0 and y == 0:
        z = 0

    point = (FQ(x), FQ(y), FQ(z))

    # Check if the point is on the curve
    if not is_on_curve(point, b):
        raise InvalidParameter("Point is not on curve")

    return point


def bytes_to_g2(data: Bytes) -> Point3D[FQ2]:
    """
    Decode 128 bytes to a G2 point.

    Parameters
    ----------
    data :
        The bytes data to decode.

    Returns
    -------
    point : Point2D
        A point on the curve.

    Raises
    ------
    InvalidParameter
        Either a field element is invalid or the point is not on the curve.

    """
    if len(data) != 128:
        raise InvalidParameter("G2 should be 128 bytes long")

    x0_bytes = buffer_read(data, U256(0), U256(32))
    x0 = int(U256.from_be_bytes(x0_bytes))
    x1_bytes = buffer_read(data, U256(32), U256(32))
    x1 = int(U256.from_be_bytes(x1_bytes))

    y0_bytes = buffer_read(data, U256(64), U256(32))
    y0 = int(U256.from_be_bytes(y0_bytes))
    y1_bytes = buffer_read(data, U256(96), U256(32))
    y1 = int(U256.from_be_bytes(y1_bytes))

    if x0 >= field_modulus or x1 >= field_modulus:
        raise InvalidParameter("Invalid field element")
    if y0 >= field_modulus or y1 >= field_modulus:
        raise InvalidParameter("Invalid field element")

    x = FQ2((x1, x0))
    y = FQ2((y1, y0))

    z = (1, 0)
    if x == FQ2((0, 0)) and y == FQ2((0, 0)):
        z = (0, 0)

    point = (x, y, FQ2(z))

    # Check if the point is on the curve
    if not is_on_curve(point, b2):
        raise InvalidParameter("Point is not on curve")

    return point


def alt_bn128_add(evm: Evm) -> None:
    """
    The ALT_BN128 addition precompiled contract.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    data = evm.message.data

    # GAS
    charge_gas(evm, GasCosts.PRECOMPILE_ECADD)

    # OPERATION
    try:
        p0 = bytes_to_g1(buffer_read(data, U256(0), U256(64)))
        p1 = bytes_to_g1(buffer_read(data, U256(64), U256(64)))
    except InvalidParameter as e:
        raise OutOfGasError from e

    p = add(p0, p1)
    x, y = normalize(p)

    evm.output = Uint(x).to_be_bytes32() + Uint(y).to_be_bytes32()


def alt_bn128_mul(evm: Evm) -> None:
    """
    The ALT_BN128 multiplication precompiled contract.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    data = evm.message.data

    # GAS
    charge_gas(evm, GasCosts.PRECOMPILE_ECMUL)

    # OPERATION
    try:
        p0 = bytes_to_g1(buffer_read(data, U256(0), U256(64)))
    except InvalidParameter as e:
        raise OutOfGasError from e
    n = int(U256.from_be_bytes(buffer_read(data, U256(64), U256(32))))

    p = multiply(p0, n)
    x, y = normalize(p)

    evm.output = Uint(x).to_be_bytes32() + Uint(y).to_be_bytes32()


def alt_bn128_pairing_check(evm: Evm) -> None:
    """
    The ALT_BN128 pairing check precompiled contract.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    data = evm.message.data

    # GAS
    charge_gas(
        evm,
        GasCosts.PRECOMPILE_ECPAIRING_PER_POINT * (ulen(data) // Uint(192))
        + GasCosts.PRECOMPILE_ECPAIRING_BASE,
    )

    # OPERATION
    if len(data) % 192 != 0:
        raise OutOfGasError
    result = FQ12.one()
    for i in range(len(data) // 192):
        try:
            p = bytes_to_g1(buffer_read(data, U256(192 * i), U256(64)))
            q = bytes_to_g2(buffer_read(data, U256(192 * i + 64), U256(128)))
        except InvalidParameter as e:
            raise OutOfGasError from e
        if not is_inf(multiply(p, curve_order)):
            raise OutOfGasError
        if not is_inf(multiply(q, curve_order)):
            raise OutOfGasError

        result *= pairing(q, p)

    if result == FQ12.one():
        evm.output = U256(1).to_be_bytes32()
    else:
        evm.output = U256(0).to_be_bytes32()

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/precompiled_contracts/blake2f.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Blake2 PRECOMPILED CONTRACT.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementation of the `Blake2` precompiled contract.
"""

from ethereum.crypto.blake2 import Blake2b

from ...vm import Evm
from ...vm.gas import GasCosts, charge_gas
from ..exceptions import InvalidParameter


def blake2f(evm: Evm) -> None:
    """
    Writes the Blake2 hash to output.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    data = evm.message.data
    if len(data) != 213:
        raise InvalidParameter

    blake2b = Blake2b()
    rounds, h, m, t_0, t_1, f = blake2b.get_blake2_parameters(data)

    charge_gas(evm, GasCosts.PRECOMPILE_BLAKE2F_PER_ROUND * rounds)
    if f not in [0, 1]:
        raise InvalidParameter

    evm.output = blake2b.compress(rounds, h, m, t_0, t_1, f)

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/precompiled_contracts/ecrecover.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) ECRECOVER PRECOMPILED CONTRACT.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementation of the `ECRECOVER` precompiled contract.
"""

from ethereum_types.numeric import U256

from ethereum.crypto.elliptic_curve import SECP256K1N, secp256k1_recover
from ethereum.crypto.hash import Hash32, keccak256
from ethereum.exceptions import InvalidSignatureError
from ethereum.utils.byte import left_pad_zero_bytes

from ...vm import Evm
from ...vm.gas import GasCosts, charge_gas
from ...vm.memory import buffer_read


def ecrecover(evm: Evm) -> None:
    """
    Decrypts the address using elliptic curve DSA recovery mechanism and writes
    the address to output.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    data = evm.message.data

    # GAS
    charge_gas(evm, GasCosts.PRECOMPILE_ECRECOVER)

    # OPERATION
    message_hash_bytes = buffer_read(data, U256(0), U256(32))
    message_hash = Hash32(message_hash_bytes)
    v = U256.from_be_bytes(buffer_read(data, U256(32), U256(32)))
    r = U256.from_be_bytes(buffer_read(data, U256(64), U256(32)))
    s = U256.from_be_bytes(buffer_read(data, U256(96), U256(32)))

    if v != U256(27) and v != U256(28):
        return
    if U256(0) >= r or r >= SECP256K1N:
        return
    if U256(0) >= s or s >= SECP256K1N:
        return

    try:
        public_key = secp256k1_recover(r, s, v - U256(27), message_hash)
    except InvalidSignatureError:
        # unable to extract public key
        return

    address = keccak256(public_key)[12:32]
    padded_address = left_pad_zero_bytes(address, 32)
    evm.output = padded_address

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/precompiled_contracts/identity.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) IDENTITY PRECOMPILED CONTRACT.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementation of the `IDENTITY` precompiled contract.
"""

from ethereum_types.numeric import Uint, ulen

from ethereum.utils.numeric import ceil32

from ...vm import Evm
from ...vm.gas import (
    GasCosts,
    charge_gas,
)


def identity(evm: Evm) -> None:
    """
    Writes the message data to output.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    data = evm.message.data

    # GAS
    word_count = ceil32(ulen(data)) // Uint(32)
    charge_gas(
        evm,
        GasCosts.PRECOMPILE_IDENTITY_BASE
        + GasCosts.PRECOMPILE_IDENTITY_PER_WORD * word_count,
    )

    # OPERATION
    evm.output = data

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/precompiled_contracts/mapping.py
================================================================================

```python
"""
Precompiled Contract Addresses.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Mapping of precompiled contracts to their implementations.
"""

from typing import Callable, Dict

from ethereum.state import Address

from . import (
    ALT_BN128_ADD_ADDRESS,
    ALT_BN128_MUL_ADDRESS,
    ALT_BN128_PAIRING_CHECK_ADDRESS,
    BLAKE2F_ADDRESS,
    ECRECOVER_ADDRESS,
    IDENTITY_ADDRESS,
    MODEXP_ADDRESS,
    RIPEMD160_ADDRESS,
    SHA256_ADDRESS,
)
from .alt_bn128 import alt_bn128_add, alt_bn128_mul, alt_bn128_pairing_check
from .blake2f import blake2f
from .ecrecover import ecrecover
from .identity import identity
from .modexp import modexp
from .ripemd160 import ripemd160
from .sha256 import sha256

PRE_COMPILED_CONTRACTS: Dict[Address, Callable] = {
    ECRECOVER_ADDRESS: ecrecover,
    SHA256_ADDRESS: sha256,
    RIPEMD160_ADDRESS: ripemd160,
    IDENTITY_ADDRESS: identity,
    MODEXP_ADDRESS: modexp,
    ALT_BN128_ADD_ADDRESS: alt_bn128_add,
    ALT_BN128_MUL_ADDRESS: alt_bn128_mul,
    ALT_BN128_PAIRING_CHECK_ADDRESS: alt_bn128_pairing_check,
    BLAKE2F_ADDRESS: blake2f,
}

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/precompiled_contracts/modexp.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) MODEXP PRECOMPILED CONTRACT.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementation of the `MODEXP` precompiled contract.
"""

from ethereum_types.bytes import Bytes
from ethereum_types.numeric import U256, Uint

from ...vm import Evm
from ...vm.gas import charge_gas
from ..memory import buffer_read

GQUADDIVISOR = Uint(20)


def modexp(evm: Evm) -> None:
    """
    Calculates `(base**exp) % modulus` for arbitrary sized `base`, `exp` and
    `modulus`. The return value is the same length as the modulus.
    """
    data = evm.message.data

    # GAS
    base_length = U256.from_be_bytes(buffer_read(data, U256(0), U256(32)))
    exp_length = U256.from_be_bytes(buffer_read(data, U256(32), U256(32)))
    modulus_length = U256.from_be_bytes(buffer_read(data, U256(64), U256(32)))

    exp_start = U256(96) + base_length

    exp_head = U256.from_be_bytes(
        buffer_read(data, exp_start, min(U256(32), exp_length))
    )

    charge_gas(
        evm,
        gas_cost(base_length, modulus_length, exp_length, exp_head),
    )

    # OPERATION
    if base_length == 0 and modulus_length == 0:
        evm.output = Bytes()
        return

    base = Uint.from_be_bytes(buffer_read(data, U256(96), base_length))
    exp = Uint.from_be_bytes(buffer_read(data, exp_start, exp_length))

    modulus_start = exp_start + exp_length
    modulus = Uint.from_be_bytes(
        buffer_read(data, modulus_start, modulus_length)
    )

    if modulus == 0:
        evm.output = Bytes(b"\x00") * modulus_length
    else:
        evm.output = pow(base, exp, modulus).to_bytes(
            Uint(modulus_length), "big"
        )


def complexity(base_length: U256, modulus_length: U256) -> Uint:
    """
    Estimate the complexity of performing a modular exponentiation.

    Parameters
    ----------
    base_length :
        Length of the array representing the base integer.

    modulus_length :
        Length of the array representing the modulus integer.

    Returns
    -------
    complexity : `Uint`
        Complexity of performing the operation.

    """
    max_length = max(Uint(base_length), Uint(modulus_length))
    if max_length <= Uint(64):
        return max_length ** Uint(2)
    elif max_length <= Uint(1024):
        return (
            max_length ** Uint(2) // Uint(4)
            + Uint(96) * max_length
            - Uint(3072)
        )
    else:
        return (
            max_length ** Uint(2) // Uint(16)
            + Uint(480) * max_length
            - Uint(199680)
        )


def iterations(exponent_length: U256, exponent_head: U256) -> Uint:
    """
    Calculate the number of iterations required to perform a modular
    exponentiation.

    Parameters
    ----------
    exponent_length :
        Length of the array representing the exponent integer.

    exponent_head :
        First 32 bytes of the exponent (with leading zero padding if it is
        shorter than 32 bytes), as a U256.

    Returns
    -------
    iterations : `Uint`
        Number of iterations.

    """
    if exponent_length < U256(32):
        adjusted_exp_length = Uint(max(0, int(exponent_head.bit_length()) - 1))
    else:
        adjusted_exp_length = Uint(
            8 * (int(exponent_length) - 32)
            + max(0, int(exponent_head.bit_length()) - 1)
        )

    return max(adjusted_exp_length, Uint(1))


def gas_cost(
    base_length: U256,
    modulus_length: U256,
    exponent_length: U256,
    exponent_head: U256,
) -> Uint:
    """
    Calculate the gas cost of performing a modular exponentiation.

    Parameters
    ----------
    base_length :
        Length of the array representing the base integer.

    modulus_length :
        Length of the array representing the modulus integer.

    exponent_length :
        Length of the array representing the exponent integer.

    exponent_head :
        First 32 bytes of the exponent (with leading zero padding if it is
        shorter than 32 bytes), as a U256.

    Returns
    -------
    gas_cost : `Uint`
        Gas required for performing the operation.

    """
    multiplication_complexity = complexity(base_length, modulus_length)
    iteration_count = iterations(exponent_length, exponent_head)
    cost = multiplication_complexity * iteration_count
    cost //= GQUADDIVISOR
    return cost

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/precompiled_contracts/ripemd160.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) RIPEMD160 PRECOMPILED CONTRACT.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementation of the `RIPEMD160` precompiled contract.
"""

import hashlib

from ethereum_types.numeric import Uint, ulen

from ethereum.utils.byte import left_pad_zero_bytes
from ethereum.utils.numeric import ceil32

from ...vm import Evm
from ...vm.gas import (
    GasCosts,
    charge_gas,
)


def ripemd160(evm: Evm) -> None:
    """
    Writes the ripemd160 hash to output.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    data = evm.message.data

    # GAS
    word_count = ceil32(ulen(data)) // Uint(32)
    charge_gas(
        evm,
        GasCosts.PRECOMPILE_RIPEMD160_BASE
        + GasCosts.PRECOMPILE_RIPEMD160_PER_WORD * word_count,
    )

    # OPERATION
    hash_bytes = hashlib.new("ripemd160", data).digest()
    padded_hash = left_pad_zero_bytes(hash_bytes, 32)
    evm.output = padded_hash

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/precompiled_contracts/sha256.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) SHA256 PRECOMPILED CONTRACT.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementation of the `SHA256` precompiled contract.
"""

import hashlib

from ethereum_types.numeric import Uint, ulen

from ethereum.utils.numeric import ceil32

from ...vm import Evm
from ...vm.gas import (
    GasCosts,
    charge_gas,
)


def sha256(evm: Evm) -> None:
    """
    Writes the sha256 hash to output.

    Parameters
    ----------
    evm :
        The current EVM frame.

    """
    data = evm.message.data

    # GAS
    word_count = ceil32(ulen(data)) // Uint(32)
    charge_gas(
        evm,
        GasCosts.PRECOMPILE_SHA256_BASE
        + GasCosts.PRECOMPILE_SHA256_PER_WORD * word_count,
    )

    # OPERATION
    evm.output = hashlib.sha256(data).digest()

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/runtime.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Runtime Operations.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Runtime related operations used while executing EVM code.
"""

from typing import Set

from ethereum_types.bytes import Bytes
from ethereum_types.numeric import Uint, ulen

from .instructions import Ops


def get_valid_jump_destinations(code: Bytes) -> Set[Uint]:
    """
    Analyze the EVM code to obtain the set of valid jump destinations.

    Valid jump destinations are defined as follows:
        * The jump destination is less than the length of the code.
        * The jump destination should have the `JUMPDEST` opcode (0x5B).
        * The jump destination shouldn't be part of the data corresponding to
          `PUSH-N` opcodes.

    Note - Jump destinations are 0-indexed.

    Parameters
    ----------
    code :
        The EVM code which is to be executed.

    Returns
    -------
    valid_jump_destinations: `Set[Uint]`
        The set of valid jump destinations in the code.

    """
    valid_jump_destinations = set()
    pc = Uint(0)

    while pc < ulen(code):
        try:
            current_opcode = Ops(code[pc])
        except ValueError:
            # Skip invalid opcodes, as they don't affect the jumpdest
            # analysis. Nevertheless, such invalid opcodes would be caught
            # and raised when the interpreter runs.
            pc += Uint(1)
            continue

        if current_opcode == Ops.JUMPDEST:
            valid_jump_destinations.add(pc)
        elif Ops.PUSH1.value <= current_opcode.value <= Ops.PUSH32.value:
            # If PUSH-N opcodes are encountered, skip the current opcode along
            # with the trailing data segment corresponding to the PUSH-N
            # opcodes.
            push_data_size = current_opcode.value - Ops.PUSH1.value + 1
            pc += Uint(push_data_size)

        pc += Uint(1)

    return valid_jump_destinations

```


================================================================================
FILE: ethereum/forks/muir_glacier/vm/stack.py
================================================================================

```python
"""
Ethereum Virtual Machine (EVM) Stack.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Implementation of the stack operators for the EVM.
"""

from typing import List

from ethereum_types.numeric import U256

from .exceptions import StackOverflowError, StackUnderflowError


def pop(stack: List[U256]) -> U256:
    """
    Pops the top item off of `stack`.

    Parameters
    ----------
    stack :
        EVM stack.

    Returns
    -------
    value : `U256`
        The top element on the stack.

    """
    if len(stack) == 0:
        raise StackUnderflowError

    return stack.pop()


def push(stack: List[U256], value: U256) -> None:
    """
    Pushes `value` onto `stack`.

    Parameters
    ----------
    stack :
        EVM stack.

    value :
        Item to be pushed onto `stack`.

    """
    if len(stack) == 1024:
        raise StackOverflowError

    return stack.append(value)

```

