# EELS NotebookLM Export

Upload **every** .md file in this folder into NotebookLM as sources (except this index if you prefer).

Generated from: `C:\projects\Scrutor\EELs\ethereum`
Date: 2026-07-25 16:33

| Document | Description |
|----------|-------------|
| `00-shared-modules.md` | 1454.2 KB |
| `fork-amsterdam.md` | 389.8 KB |
| `fork-arrow_glacier.md` | 233.2 KB |
| `fork-berlin.md` | 224 KB |
| `fork-bpo1.md` | 303.5 KB |
| `fork-bpo2.md` | 303.4 KB |
| `fork-bpo3.md` | 303.4 KB |
| `fork-bpo4.md` | 303.5 KB |
| `fork-bpo5.md` | 303.5 KB |
| `fork-byzantium.md` | 204 KB |
| `fork-cancun.md` | 245.7 KB |
| `fork-constantinople.md` | 209.9 KB |
| `fork-dao_fork.md` | 195.8 KB |
| `fork-frontier.md` | 175.2 KB |
| `fork-gray_glacier.md` | 233.1 KB |
| `fork-homestead.md` | 178.8 KB |
| `fork-istanbul.md` | 213.7 KB |
| `fork-london.md` | 234 KB |
| `fork-muir_glacier.md` | 213.1 KB |
| `fork-osaka.md` | 305.1 KB |
| `fork-paris.md` | 221.1 KB |
| `fork-prague.md` | 299.6 KB |
| `fork-shanghai.md` | 225.7 KB |
| `fork-spurious_dragon.md` | 186.1 KB |
| `fork-tangerine_whistle.md` | 180.8 KB |

## NotebookLM tips

1. Create a new notebook.
2. Add sources → upload all `fork-*.md` plus `00-shared-modules.md`.
3. If a file is rejected for size, split is already by fork; shared is separate.
4. Ask questions citing fork names (e.g. Prague gas, Cancun blobs).
